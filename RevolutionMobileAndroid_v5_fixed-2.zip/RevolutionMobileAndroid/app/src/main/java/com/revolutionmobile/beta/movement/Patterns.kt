/*
 * Revolution Mobile Beta — GPL-3.0-or-later.
 *
 * Gathering patterns ported from Natro Macro's the patterns directory (*.ahk files)
 * (https://github.com/NatroTeam/NatroMacro), Copyright © Natro Team, GNU GPL v3.
 * Key presses are kept as Down/Up commands; keys are mapped to joystick directions.
 * See NOTICE and LICENSE.
 */
package com.revolutionmobile.beta.movement

/**
 * Natro's naming: TC = towards corner, AFC = away from corner, FB = forward/back, LR = left/right.
 * Inversion flags come from the field settings. [fwd] is Natro's physical FwdKey and is never inverted.
 */
class PatternContext(
    val size: Double = 1.0,
    val reps: Int = 1,
    invertFB: Boolean = false,
    invertLR: Boolean = false,
    val facingCorner: Boolean = false
) {
    init {
        require(size > 0.0) { "size must be positive" }
        require(reps >= 1) { "reps must be at least 1" }
    }

    val tcfb: Dir = if (invertFB) Dir.BACK else Dir.FWD
    val afcfb: Dir = if (invertFB) Dir.FWD else Dir.BACK
    val tclr: Dir = if (invertLR) Dir.RIGHT else Dir.LEFT
    val afclr: Dir = if (invertLR) Dir.LEFT else Dir.RIGHT
    val fwd: Dir = Dir.FWD
}

object Patterns {
    private fun diag(a: Double, b: Double): Double = Math.sqrt(a * a + b * b)

    fun snake(c: PatternContext): List<Cmd> = script {
        val s = c.size
        repeat(c.reps) {
            down(c.tclr); walk(11 * s); up(c.tclr)
            down(c.tcfb); walk(1.0); up(c.tcfb)
            down(c.afclr); walk(11 * s); up(c.afclr)
            down(c.tcfb); walk(1.0); up(c.tcfb)
        }
        repeat(c.reps) {
            down(c.tclr); walk(11 * s); up(c.tclr)
            down(c.afcfb); walk(1.0); up(c.afcfb)
            down(c.afclr); walk(11 * s); up(c.afclr)
            down(c.afcfb); walk(1.0); up(c.afcfb)
        }
    }

    fun xSnake(c: PatternContext): List<Cmd> = script {
        val s = c.size
        repeat(c.reps) {
            down(c.tclr); walk(4 * s); up(c.tclr)
            down(c.tcfb); walk(2 * s); up(c.tcfb)
            down(c.afclr); walk(8 * s); up(c.afclr)
            down(c.tcfb); walk(2 * s); up(c.tcfb)
            down(c.tclr); walk(8 * s); up(c.tclr)
            down(c.afclr, c.afcfb); walk(diag(8 * s, 8 * s)); up(c.afclr, c.afcfb)
            down(c.tclr); walk(8 * s); up(c.tclr)
            down(c.tcfb); walk(2 * s); up(c.tcfb)
            down(c.afclr); walk(8 * s); up(c.afclr)
            down(c.tcfb); walk(6.7 * s); up(c.tcfb)
            down(c.tclr); walk(8 * s); up(c.tclr)
            down(c.afcfb); walk(2 * s); up(c.afcfb)
            down(c.afclr); walk(8 * s); up(c.afclr)
            down(c.afcfb); walk(2 * s); up(c.afcfb)
            down(c.tclr); walk(8 * s); up(c.tclr)
            down(c.afcfb); walk(2 * s); up(c.afcfb)
            down(c.afclr); walk(8 * s); up(c.afclr)
            down(c.afcfb); walk(3 * s); up(c.afcfb)
            down(c.tclr); walk(8 * s); up(c.tclr)
            down(c.tcfb, c.afclr); walk(diag(4 * s, 4 * s)); up(c.tcfb, c.afclr)
        }
    }

    fun cornerXSnake(c: PatternContext): List<Cmd> = script {
        val s = c.size
        val r = c.reps.toDouble()
        down(c.tclr); walk(4 * s); up(c.tclr)
        down(c.tcfb); walk(2 * s); up(c.tcfb)
        down(c.afclr); walk(8 * s); up(c.afclr)
        down(c.tcfb); walk(2 * s); up(c.tcfb)
        down(c.tclr); walk(8 * s); up(c.tclr)
        down(c.afclr, c.afcfb); walk(diag(8 * s, 8 * s)); up(c.afclr, c.afcfb)
        down(c.tclr); walk(8 * s)
        up(c.tclr); down(c.tcfb); walk(2 * s)
        up(c.tcfb); down(c.afclr); walk(8 * s)
        up(c.afclr); down(c.tcfb); walk(6.7 * s + 10)
        up(c.tcfb); down(c.afclr); walk(6 + r)
        down(c.tcfb); walk(3.0)
        up(c.afclr, c.tcfb); down(c.tclr); walk(2 + r)
        up(c.tclr); down(c.afcfb); walk(5.0)
        up(c.afcfb); down(c.tclr); walk(8 * s)
        up(c.tclr); down(c.afcfb); walk(2 * s)
        up(c.afcfb); down(c.afclr); walk(8 * s)
        up(c.afclr); down(c.afcfb); walk(2 * s)
        up(c.afcfb); down(c.tclr); walk(8 * s)
        up(c.tclr); down(c.afcfb); walk(2 * s)
        up(c.afcfb); down(c.afclr); walk(8 * s)
        up(c.afclr); down(c.afcfb); walk(3 * s)
        up(c.afcfb); down(c.tclr); walk(8 * s)
        up(c.tclr); down(c.tcfb, c.afclr); walk(diag(4 * s, 4 * s))
        up(c.tcfb, c.afclr)
    }

    fun lines(c: PatternContext): List<Cmd> = script {
        val s = c.size
        repeat(c.reps) {
            down(c.tcfb); walk(11 * s); up(c.tcfb)
            down(c.tclr); walk(1.0); up(c.tclr)
            down(c.afcfb); walk(11 * s); up(c.afcfb)
            down(c.tclr); walk(1.0); up(c.tclr)
        }
        repeat(c.reps) {
            down(c.tcfb); walk(11 * s); up(c.tcfb)
            down(c.afclr); walk(1.0); up(c.afclr)
            down(c.afcfb); walk(11 * s); up(c.afcfb)
            down(c.afclr); walk(1.0); up(c.afclr)
        }
    }

    fun diamonds(c: PatternContext): List<Cmd> = script {
        val s = c.size
        for (i in 1..c.reps) {
            val d = 5 * s + i
            down(c.tcfb, c.tclr); walk(d); up(c.tclr)
            down(c.afclr); walk(d); up(c.tcfb)
            down(c.afcfb); walk(d); up(c.afclr)
            down(c.tclr); walk(d); up(c.tclr, c.afcfb)
        }
    }

    fun squares(c: PatternContext): List<Cmd> = script {
        val s = c.size
        for (i in 1..c.reps) {
            val d = 5 * s + i
            down(c.tcfb); walk(d); up(c.tcfb)
            down(c.tclr); walk(d); up(c.tclr)
            down(c.afcfb); walk(d); up(c.afcfb)
            down(c.afclr); walk(d); up(c.afclr)
        }
    }

    fun slimline(c: PatternContext): List<Cmd> = script {
        val s = c.size
        down(c.tclr); walk(4 * s + c.reps * 0.1 - 0.1); up(c.tclr)
        down(c.afclr); walk(8 * s); up(c.afclr)
        down(c.tclr); walk(4 * s); up(c.tclr)
    }

    fun fork(c: PatternContext): List<Cmd> = script {
        val s = c.size
        val gap = 0.75
        val diagGap = gap * Math.sqrt(2.0)
        val len = (40 - gap * 16 - diagGap * 4) / 6
        if (c.facingCorner) {
            down(c.fwd); walk(1.5, 10); up(c.fwd)
        }
        down(c.tclr, c.afcfb); walk(diagGap * 2); up(c.afcfb)
        walk(((c.reps - 1) * 4 + 2) * gap)
        down(c.tcfb); walk(diagGap * 2); up(c.tclr)
        repeat(c.reps) {
            walk(len * s, 99); up(c.tcfb); down(c.afclr); walk(gap * 2); up(c.afclr)
            down(c.afcfb); walk(len * s, 99); up(c.afcfb); down(c.afclr); walk(gap * 2)
            up(c.afclr); down(c.tcfb)
        }
        walk(len * s, 99); up(c.tcfb); down(c.afclr); walk(gap * 2); up(c.afclr)
        down(c.afcfb); walk(len * s, 99); up(c.afcfb)
    }

    fun auryn(c: PatternContext): List<Cmd> = script {
        val s = c.size
        for (i in 1..c.reps) {
            val u = 175.0 * 9.0 / 2000.0 * s * i * 1.1
            // infinity
            down(c.tcfb); walk(u)
            down(c.tclr); walk(u * 1.4)
            up(c.tcfb); walk(u)
            down(c.afcfb); walk(u * 3 * 1.4)
            up(c.afcfb); walk(u)
            down(c.tcfb); walk(u * 1.4)
            up(c.tclr); walk(u)
            down(c.afclr); walk(u * 1.4)
            up(c.tcfb); walk(u)
            down(c.afcfb); walk(u * 3 * 1.4)
            up(c.afcfb); walk(u)
            down(c.tcfb); walk(u * 1.4)
            up(c.afclr)
            // big circle
            walk(u * 2)
            down(c.tclr); walk(u * 2 * 1.4)
            up(c.tcfb); walk(u * 2)
            down(c.afcfb); walk(u * 2 * 1.4)
            up(c.tclr); walk(u * 2)
            down(c.afclr); walk(u * 2 * 1.4)
            up(c.afcfb); walk(u * 2)
            down(c.tcfb); walk(u * 2 * 1.4)
            up(c.afclr)
            // flip: half circle to the other side
            walk(u * 2)
            down(c.tclr); walk(u * 2 * 1.4)
            up(c.tcfb); walk(u * 2)
            down(c.afcfb); walk(u * 2 * 1.4)
            up(c.tclr, c.afcfb)
            sleep(50L)
            // reverse infinity
            down(c.afcfb); walk(u)
            down(c.afclr); walk(u * 1.4)
            up(c.afcfb); walk(u)
            down(c.tcfb); walk(u * 3 * 1.4)
            up(c.tcfb); walk(u)
            down(c.afcfb); walk(u * 1.4)
            up(c.afclr); walk(u)
            down(c.tclr); walk(u * 1.4)
            up(c.afcfb); walk(u)
            down(c.tcfb); walk(u * 1.4)
            up(c.tcfb); walk(u)
            down(c.afcfb); walk(u * 1.4)
            up(c.tclr)
            // reverse big circle
            walk(u * 2)
            down(c.afclr); walk(u * 2 * 1.4)
            up(c.afcfb); walk(u * 2)
            down(c.tcfb); walk(u * 2 * 1.4)
            up(c.afclr); walk(u * 2)
            down(c.tclr); walk(u * 2 * 1.4)
            up(c.tcfb); walk(u * 2)
            down(c.afcfb); walk(u * 2 * 1.4)
            up(c.tclr)
            // reverse flip
            walk(u * 2)
            down(c.afclr); walk(u * 2 * 1.4)
            up(c.afcfb); walk(u * 2)
            down(c.tcfb); walk(u * 2 * 1.4)
            up(c.afclr, c.tcfb)
        }
    }

    fun superCat(c: PatternContext): List<Cmd> = script {
        val s = c.size
        repeat(c.reps) {
            down(c.tclr); walk(1.25 * s); up(c.tclr)
            down(c.tcfb); walk(7 * s, 10); up(c.tcfb)
            down(c.tclr); walk(1.25 * s); up(c.tclr)
            down(c.afcfb); walk(6.66 * s, 10); up(c.afcfb)
            down(c.tclr); walk(1.25 * s); up(c.tclr)
            down(c.tcfb); walk(7 * s, 10); up(c.tcfb)
            down(c.tclr); walk(2 * s); up(c.tclr)
            down(c.afcfb); walk(6.5 * s, 10); up(c.afcfb)
        }
        repeat(c.reps) {
            down(c.afclr); walk(1.25 * s); up(c.afclr)
            down(c.tcfb); walk(7 * s, 10); up(c.tcfb)
            down(c.afclr); walk(1.0 * s); up(c.afclr)
            down(c.afcfb); walk(6.66 * s, 10); up(c.afcfb)
            down(c.afclr); walk(1.25 * s); up(c.afclr)
            down(c.tcfb); walk(7 * s, 10); up(c.tcfb)
            down(c.afclr); walk(1.25 * s); up(c.afclr)
            down(c.afcfb); walk(6.5 * s, 10); up(c.afcfb)
        }
    }

    fun eLol(c: PatternContext): List<Cmd> = script {
        val s = c.size
        val sd = 274.0
        val fc = if (c.facingCorner) 1.0 else 0.0
        val r = c.reps
        down(c.tclr); walk(sd * 9 / 2000 * (r * 2 + 1)); up(c.tclr)
        down(c.afcfb); walk(5 * s); up(c.afcfb)
        repeat(c.reps) {
            down(c.afclr); walk(sd * 9 / 2000); up(c.afclr); down(c.tcfb); walk(5 * s); up(c.tcfb)
            down(c.afclr); walk(sd * 9 / 2000); up(c.afclr); down(c.afcfb)
            walk((1094 + 25 * fc) * 9 / 2000 * s); up(c.afcfb)
        }
        down(c.tclr); walk(sd * 9 / 2000 * (r * 2 + 0.5)); up(c.tclr)
        down(c.tcfb); walk(5 * s); up(c.tcfb)
        repeat(c.reps) {
            down(c.afclr); walk(sd * 9 / 2000); up(c.afclr); down(c.afcfb)
            walk((1094 + 25 * fc) * 9 / 2000 * s); up(c.afcfb); down(c.afclr)
            walk(sd * 9 / 2000 * 1.5); up(c.afclr); down(c.tcfb); walk(5 * s); up(c.tcfb)
        }
    }

    fun stationary(@Suppress("UNUSED_PARAMETER") c: PatternContext): List<Cmd> = script {
        sleep(10_000L)
    }
}

/** Gathering patterns offered in the test screen. Labels match Natro's file names. */
enum class GatherPattern(val label: String, val build: (PatternContext) -> List<Cmd>) {
    SNAKE("Snake", { Patterns.snake(it) }),
    X_SNAKE("XSnake", { Patterns.xSnake(it) }),
    CORNER_X_SNAKE("CornerXSnake", { Patterns.cornerXSnake(it) }),
    LINES("Lines", { Patterns.lines(it) }),
    DIAMONDS("Diamonds", { Patterns.diamonds(it) }),
    SQUARES("Squares", { Patterns.squares(it) }),
    SLIMLINE("Slimline", { Patterns.slimline(it) }),
    FORK("Fork", { Patterns.fork(it) }),
    AURYN("Auryn", { Patterns.auryn(it) }),
    SUPER_CAT("SuperCat", { Patterns.superCat(it) }),
    E_LOL("e_lol", { Patterns.eLol(it) }),
    STATIONARY("Stationary", { Patterns.stationary(it) })
}
