/*
 * Revolution Mobile Beta — GPL-3.0-or-later.
 * A gather or travel route. Ported from Natro Macro's the paths directory (*.ahk files)
 * (https://github.com/NatroTeam/NatroMacro), Copyright © Natro Team, GNU GPL v3.
 * See NOTICE and LICENSE.
 */
package com.revolutionmobile.beta.movement.routes

import com.revolutionmobile.beta.movement.Cmd
import com.revolutionmobile.beta.movement.RuntimeContext

interface Route {
    /** Human-readable name for the UI. */
    val name: String

    /**
     * False when this route cannot run for [ctx] yet, for example a movement method
     * that has not been ported. Callers must check this before [build].
     */
    fun supports(ctx: RuntimeContext): Boolean

    /** Builds the command list for [ctx]. Requires [supports] to be true. */
    fun build(ctx: RuntimeContext): List<Cmd>
}
