package com.revolutionmobile.beta.config

import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test

class AppConfigTest {
    @Test
    fun defaultsAreAWalkingHiveOneAtBaseSpeed() {
        val config = AppConfig()
        assertEquals(1, config.hiveSlot)
        assertEquals(MoveMethod.WALK, config.moveMethod)
        assertEquals(28, config.baseMoveSpeed)
    }

    @Test
    fun hiveSlotOutsideOneToSixIsRejected() {
        assertThrows(IllegalArgumentException::class.java) { AppConfig(hiveSlot = 0) }
        assertThrows(IllegalArgumentException::class.java) { AppConfig(hiveSlot = 7) }
    }

    @Test
    fun beesAndSpeedAreBounded() {
        assertThrows(IllegalArgumentException::class.java) { AppConfig(hiveBees = 51) }
        assertThrows(IllegalArgumentException::class.java) { AppConfig(baseMoveSpeed = 0) }
    }
}
