package com.revolutionmobile.beta.movement

import com.revolutionmobile.beta.input.Vector2
import com.revolutionmobile.beta.movement.GameButton
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class StepRunnerActionsTest {
    private class Motion : StepRunner.MotionSink {
        override fun drive(direction: Vector2, durationMs: Long, onDone: (Boolean) -> Unit) = onDone(true)
    }

    private class Immediate : StepRunner.Scheduler {
        override fun postDelayed(delayMs: Long, action: () -> Unit) = action()
        override fun cancelAll() = Unit
    }

    private class Actions(private val result: Boolean = true) : StepRunner.ActionSink {
        val jumps = mutableListOf<Pair<Vector2?, Long>>()
        val turns = mutableListOf<Turn>()
        val taps = mutableListOf<Pair<GameButton, Long>>()

        override fun jump(moving: Vector2?, holdMs: Long, onDone: (Boolean) -> Unit) {
            jumps += moving to holdMs
            onDone(result)
        }

        override fun turnCamera(turn: Turn, onDone: (Boolean) -> Unit) {
            turns += turn
            onDone(result)
        }

        override fun tap(button: GameButton, holdMs: Long, onDone: (Boolean) -> Unit) {
            taps += button to holdMs
            onDone(result)
        }
    }

    @Test
    fun jumpWhileMovingPassesTheHeldVector() {
        val actions = Actions()
        var finished: Boolean? = null
        StepRunner(Motion(), Immediate(), actions) { 28.0 }
            .start(script { down(Dir.FWD); jump(200L); up(Dir.FWD) }) { finished = it }
        assertEquals(listOf<Pair<Vector2?, Long>>(Vector2(0f, -1f) to 200L), actions.jumps)
        assertEquals(true, finished)
    }

    @Test
    fun jumpWithoutMovementPassesNull() {
        val actions = Actions()
        StepRunner(Motion(), Immediate(), actions) { 28.0 }.start(script { jump(100L) })
        assertEquals(listOf<Pair<Vector2?, Long>>(null to 100L), actions.jumps)
    }

    @Test
    fun rotateSendsOneSwipePerStep() {
        val actions = Actions()
        StepRunner(Motion(), Immediate(), actions) { 28.0 }.start(script { rotate(Turn.LEFT, 4) })
        assertEquals(List(4) { Turn.LEFT }, actions.turns)
    }

    @Test
    fun failedJumpStopsTheRunAndSkipsLaterSteps() {
        val actions = Actions(result = false)
        var finished: Boolean? = null
        val runner = StepRunner(Motion(), Immediate(), actions) { 28.0 }
        runner.start(script { jump(100L); rotate(Turn.RIGHT, 2) }) { finished = it }
        assertTrue(actions.turns.isEmpty())
        assertEquals(false, finished)
        assertFalse(runner.running)
    }

    @Test
    fun tapSendsTheButtonWithItsHoldTime() {
        val actions = Actions()
        var finished: Boolean? = null
        StepRunner(Motion(), Immediate(), actions) { 28.0 }
            .start(script { tap(GameButton.INTERACT, 10L) }) { finished = it }
        assertEquals(listOf(GameButton.INTERACT to 10L), actions.taps)
        assertEquals(true, finished)
    }

    @Test
    fun withoutAnActionSinkJumpReportsFailure() {
        var finished: Boolean? = null
        StepRunner(Motion(), Immediate()) { 28.0 }.start(script { jump(100L) }) { finished = it }
        assertEquals(false, finished)
    }
}
