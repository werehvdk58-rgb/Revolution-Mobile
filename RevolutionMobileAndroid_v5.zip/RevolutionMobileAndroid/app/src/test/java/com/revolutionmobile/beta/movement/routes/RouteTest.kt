package com.revolutionmobile.beta.movement.routes

import com.revolutionmobile.beta.config.AppConfig
import com.revolutionmobile.beta.config.MoveMethod
import com.revolutionmobile.beta.movement.Cmd
import com.revolutionmobile.beta.movement.Dir
import com.revolutionmobile.beta.movement.GameButton
import com.revolutionmobile.beta.movement.RuntimeContext
import com.revolutionmobile.beta.movement.Turn
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Test

class RouteTest {
    private fun ctx(slot: Int = 1, method: MoveMethod = MoveMethod.WALK, bees: Int = 50) =
        RuntimeContext(AppConfig(hiveSlot = slot, moveMethod = method, hiveBees = bees))

    private fun assertNoKeysLeftHeld(label: String, commands: List<Cmd>) {
        val held = mutableSetOf<Dir>()
        for (cmd in commands) {
            when (cmd) {
                is Cmd.Down -> held += cmd.dir
                is Cmd.Up -> held -= cmd.dir
                else -> Unit
            }
        }
        assertTrue("$label leaves keys held: $held", held.isEmpty())
    }

    @Test
    fun wfPinetreeHiveSlotChangesTheReturnWalk() {
        val slotThree = WfPinetreeRoute().build(ctx(slot = 3))
        val slotOne = WfPinetreeRoute().build(ctx(slot = 1))
        assertEquals(0, slotThree.count { it == Cmd.Walk(35.0) })
        assertEquals(1, slotOne.count { it == Cmd.Walk(35.0) })
    }

    @Test
    fun wfPinetreeContainsJumpCameraTurnAndPause() {
        val commands = WfPinetreeRoute().build(ctx())
        assertTrue(commands.contains(Cmd.Jump(200L)))
        assertTrue(commands.contains(Cmd.Rotate(Turn.LEFT, 4)))
        assertTrue(commands.contains(Cmd.Sleep(50L)))
    }

    @Test
    fun wfPinetreeSupportsBothBranches() {
        assertTrue(WfPinetreeRoute().supports(ctx(method = MoveMethod.CANNON, bees = 30)))
        assertTrue(WfPinetreeRoute().supports(ctx(method = MoveMethod.WALK, bees = 50)))
    }

    @Test
    fun wfPinetreeCannonBranchUsesInteract() {
        val cannon = WfPinetreeRoute().build(ctx(method = MoveMethod.CANNON, bees = 30))
        val walk = WfPinetreeRoute().build(ctx(method = MoveMethod.WALK))
        assertTrue(cannon.contains(Cmd.Tap(GameButton.INTERACT, 10L)))
        assertTrue(cannon.count { it == Cmd.Rotate(Turn.RIGHT, 1) } == 4)
        assertFalse(walk.contains(Cmd.Tap(GameButton.INTERACT, 10L)))
    }

    @Test
    fun wfPinetreeBeeCountPicksBranch() {
        val lowBees = WfPinetreeRoute().build(ctx(method = MoveMethod.CANNON, bees = 10))
        assertTrue(lowBees.contains(Cmd.Rotate(Turn.LEFT, 4)))
    }

    @Test
    fun tunnelBearNeedsWalkMethod() {
        assertTrue(TunnelBearRoute(TunnelBear.RED).supports(ctx(method = MoveMethod.WALK)))
        assertFalse(TunnelBearRoute(TunnelBear.RED).supports(ctx(method = MoveMethod.CANNON)))
    }

    @Test
    fun tunnelBearVariantsAreDistinctRoutes() {
        val lists = TunnelBear.entries.map { TunnelBearRoute(it).build(ctx()) }
        assertEquals(TunnelBear.entries.size, lists.toSet().size)
    }

    @Test
    fun blueTunnelBearJumpsBeforeItsSharedTail() {
        val commands = TunnelBearRoute(TunnelBear.BLUE).build(ctx())
        assertTrue(commands.contains(Cmd.Jump(100L)))
        assertTrue(commands.contains(Cmd.Rotate(Turn.LEFT, 2)))
    }

    @Test
    fun everyRouteReleasesAllKeysForAnyHiveSlot() {
        for (slot in AppConfig.MIN_HIVE_SLOT..AppConfig.MAX_HIVE_SLOT) {
            for (method in MoveMethod.entries) {
                val context = ctx(slot = slot, method = method, bees = 30)
                assertNoKeysLeftHeld("wf-pinetree $method slot $slot", WfPinetreeRoute().build(context))
                if (method == MoveMethod.WALK) {
                    for (bear in TunnelBear.entries) {
                        assertNoKeysLeftHeld("${bear.label} slot $slot", TunnelBearRoute(bear).build(context))
                    }
                }
            }
        }
    }

    @Test
    fun routeSpeedComesFromContext() {
        val fast = RuntimeContext(AppConfig(baseMoveSpeed = 56))
        assertEquals(56.0, fast.studsPerSecond(), 1e-9)
    }
}
