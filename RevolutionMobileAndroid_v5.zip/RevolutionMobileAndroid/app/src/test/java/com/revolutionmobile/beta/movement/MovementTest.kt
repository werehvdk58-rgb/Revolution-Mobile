package com.revolutionmobile.beta.movement

import com.revolutionmobile.beta.input.Vector2
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class MovementTest {
    @Test
    fun baseSpeedWithoutBuffsIsUnchanged() {
        assertEquals(28.0, MoveSpeed.studsPerSecond(28), 1e-9)
    }

    @Test
    fun buffsFollowNatroFormula() {
        assertEquals(30.8, MoveSpeed.studsPerSecond(28, MoveBuffs(hastyGuard = true)), 1e-9)
        assertEquals(36.4, MoveSpeed.studsPerSecond(28, MoveBuffs(haste = 3)), 1e-9)
        assertEquals(56.0, MoveSpeed.studsPerSecond(28, MoveBuffs(hastePlus = true)), 1e-9)
        assertEquals(42.0, MoveSpeed.studsPerSecond(28, MoveBuffs(coconutHaste = true, bear = true)), 1e-9)
    }

    @Test
    fun hasteCapIgnoresLowStacks() {
        assertEquals(28.0, MoveSpeed.studsPerSecond(28, MoveBuffs(haste = 3), hasteCap = 3), 1e-9)
        assertEquals(30.8, MoveSpeed.studsPerSecond(28, MoveBuffs(haste = 4), hasteCap = 3), 1e-9)
    }

    @Test
    fun walkTimeUsesFourStudsPerTileMinusHeadStart() {
        assertEquals((4.0 - 0.125) / 28.0, MoveSpeed.walkSeconds(1.0, 28.0), 1e-9)
        assertEquals(0.0, MoveSpeed.walkSeconds(0.0, 28.0), 1e-9)
    }

    private fun assertNoKeysLeftHeld(label: String, commands: List<Cmd>) {
        val held = mutableSetOf<Dir>()
        for (cmd in commands) {
            when (cmd) {
                is Cmd.Down -> held += cmd.dir
                is Cmd.Up -> held -= cmd.dir
                else -> Unit
            }
        }
        assertTrue("$label leaves keys held: $held", held.isEmpty())
    }

    @Test
    fun everyPatternReleasesAllKeysForAllSettings() {
        for (pattern in GatherPattern.entries) {
            for (reps in 1..2) for (size in listOf(0.25, 1.0, 2.0)) {
                for (fb in listOf(false, true)) for (lr in listOf(false, true)) for (corner in listOf(false, true)) {
                    val ctx = PatternContext(size = size, reps = reps, invertFB = fb, invertLR = lr, facingCorner = corner)
                    val commands = pattern.build(ctx)
                    assertTrue(pattern.label, commands.isNotEmpty())
                    assertNoKeysLeftHeld("${pattern.label} reps=$reps size=$size fb=$fb lr=$lr corner=$corner", commands)
                }
            }
        }
    }

    @Test
    fun snakeFirstWalkIsElevenTilesTimesSize() {
        val first = Patterns.snake(PatternContext(size = 1.0)).filterIsInstance<Cmd.Walk>().first()
        assertEquals(Cmd.Walk(11.0), first)
    }

    @Test
    fun invertedLeftRightSwapsFirstDirection() {
        val first = Patterns.snake(PatternContext(invertLR = true)).first()
        assertEquals(Cmd.Down(Dir.RIGHT), first)
    }

    @Test
    fun staticPatternHasOnlySleep() {
        assertEquals(listOf<Cmd>(Cmd.Sleep(10_000L)), Patterns.stationary(PatternContext()))
    }

    private class Recorder : StepRunner.MotionSink {
        val calls = mutableListOf<Pair<Vector2, Long>>()
        override fun drive(direction: Vector2, durationMs: Long, onDone: (Boolean) -> Unit) {
            calls += direction to durationMs
            onDone(true)
        }
    }

    private class Waits : StepRunner.Scheduler {
        val delays = mutableListOf<Long>()
        override fun postDelayed(delayMs: Long, action: () -> Unit) {
            delays += delayMs
            action()
        }
        override fun cancelAll() = Unit
    }

    @Test
    fun forwardPlusRightIsOneDiagonalGesture() {
        val sink = Recorder()
        val runner = StepRunner(sink, Waits()) { 28.0 }
        var finished: Boolean? = null
        runner.start(script { down(Dir.FWD, Dir.RIGHT); walk(1.0); up(Dir.FWD, Dir.RIGHT) }) { finished = it }
        assertEquals(1, sink.calls.size)
        assertEquals(Vector2(1f, -1f), sink.calls[0].first)
        assertEquals(MoveSpeed.walkMillis(1.0, 28.0), sink.calls[0].second)
        assertEquals(true, finished)
        assertFalse(runner.running)
    }

    @Test
    fun opposingKeysCancelOut() {
        val sink = Recorder()
        val waits = Waits()
        val runner = StepRunner(sink, waits) { 28.0 }
        runner.start(script { down(Dir.FWD, Dir.BACK); walk(1.0) })
        assertTrue(sink.calls.isEmpty())
        assertEquals(listOf(MoveSpeed.walkMillis(1.0, 28.0)), waits.delays)
    }

    @Test
    fun walkWithNoKeysOnlyWaits() {
        val sink = Recorder()
        val waits = Waits()
        StepRunner(sink, waits) { 28.0 }.start(script { walk(1.0) })
        assertTrue(sink.calls.isEmpty())
        assertEquals(listOf(MoveSpeed.walkMillis(1.0, 28.0)), waits.delays)
    }

    @Test
    fun longWalksAreSplitIntoGestures() {
        val sink = Recorder()
        val runner = StepRunner(sink, Waits()) { 4.0 }
        runner.start(script { down(Dir.LEFT); walk(20.0) })
        assertTrue(sink.calls.size > 1)
        assertTrue(sink.calls.all { it.second <= StepRunner.MAX_CHUNK_MS })
        assertEquals(MoveSpeed.walkMillis(20.0, 4.0), sink.calls.sumOf { it.second })
    }

    @Test
    fun stopPreventsRemainingGestures() {
        val waits = Waits()
        lateinit var runner: StepRunner
        val sink = object : StepRunner.MotionSink {
            var calls = 0
            override fun drive(direction: Vector2, durationMs: Long, onDone: (Boolean) -> Unit) {
                calls++
                runner.stop()
                onDone(true)
            }
        }
        runner = StepRunner(sink, waits) { 28.0 }
        var finished: Boolean? = null
        runner.start(script { down(Dir.FWD); walk(20.0); up(Dir.FWD) }) { finished = it }
        assertEquals(1, sink.calls)
        assertNull(finished)
        assertFalse(runner.running)
    }

    @Test
    fun failedGestureReportsFalse() {
        val sink = StepRunner.MotionSink { _, _, onDone -> onDone(false) }
        var finished: Boolean? = null
        val runner = StepRunner(sink, Waits()) { 28.0 }
        runner.start(script { down(Dir.FWD); walk(1.0) }) { finished = it }
        assertEquals(false, finished)
        assertFalse(runner.running)
    }
}
