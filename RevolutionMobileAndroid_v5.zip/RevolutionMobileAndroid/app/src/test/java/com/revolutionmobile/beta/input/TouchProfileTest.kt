package com.revolutionmobile.beta.input

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class TouchProfileTest {
    @Test
    fun normalizedPointScalesToScreenPixels() {
        val point = NormalizedPoint(0.5f, 0.25f).toPixels(1080, 2400)
        assertEquals(PixelPoint(540, 600), point)
    }

    @Test
    fun joystickTargetMovesInExpectedDirection() {
        val profile = TouchProfile()
        val center = profile.joystickCenter.toPixels(1080, 2400)
        val forward = profile.joystickTarget(MovementKey.FORWARD.joystick, 1080, 2400)
        assertEquals(center.x, forward.x)
        assertTrue(forward.y < center.y)
    }

    @Test
    fun diagonalMovementIsNormalizedAndRemainsOnScreen() {
        val profile = TouchProfile()
        val target = profile.joystickTarget(MovementKey.FORWARD_RIGHT.joystick, 720, 1600)
        assertTrue(target.x in 0 until 720)
        assertTrue(target.y in 0 until 1600)
        assertTrue(target.x > profile.joystickCenter.toPixels(720, 1600).x)
        assertTrue(target.y < profile.joystickCenter.toPixels(720, 1600).y)
    }

    @Test
    fun cameraTargetRemainsInsideScreenBounds() {
        val profile = TouchProfile(cameraCenter = NormalizedPoint(0.95f, 0.95f))
        val target = profile.cameraTarget(CameraKey.ROTATE_RIGHT.delta, 100, 200)
        assertTrue(target.x in 0 until 100)
        assertTrue(target.y in 0 until 200)
    }
}
