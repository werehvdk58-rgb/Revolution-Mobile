/*
 * Revolution Mobile Beta — GPL-3.0-or-later.
 * Port of Natro Macro's paths/gtb-blue.ahk, gtb-red.ahk and gtb-mountain.ahk, walk branches only
 * (https://github.com/NatroTeam/NatroMacro), Copyright © Natro Team, GNU GPL v3.
 * See NOTICE and LICENSE.
 *
 * Precondition: the character already stands at the ramp. Natro's nm_gotoramp() (hive → ramp)
 * is not in the source archive, so it is not ported yet. Call it manually before the run.
 */
package com.revolutionmobile.beta.movement.routes

import com.revolutionmobile.beta.config.MoveMethod
import com.revolutionmobile.beta.movement.Cmd
import com.revolutionmobile.beta.movement.Dir.BACK
import com.revolutionmobile.beta.movement.Dir.FWD
import com.revolutionmobile.beta.movement.Dir.LEFT
import com.revolutionmobile.beta.movement.Dir.RIGHT
import com.revolutionmobile.beta.movement.RuntimeContext
import com.revolutionmobile.beta.movement.Turn
import com.revolutionmobile.beta.movement.script

/** Which Tunnel Bear the route walks to. Each one is a separate Natro path file. */
enum class TunnelBear(val label: String) {
    BLUE("Blue"),
    RED("Red"),
    MOUNTAIN("Mountain")
}

class TunnelBearRoute(val bear: TunnelBear) : Route {
    override val name: String = "Tunnel Bear (${bear.label})"

    /** Only the walk branch is ported. The cannon branches need the E key and nm_gotocannon. */
    override fun supports(ctx: RuntimeContext): Boolean = ctx.moveMethod == MoveMethod.WALK

    override fun build(ctx: RuntimeContext): List<Cmd> {
        require(supports(ctx)) { "Tunnel Bear cannon branch is not ported yet" }
        return when (bear) {
            TunnelBear.BLUE -> blue()
            TunnelBear.RED -> red()
            TunnelBear.MOUNTAIN -> mountain()
        }
    }

    private fun blue(): List<Cmd> = script {
        nmWalk(88.875, BACK, LEFT)
        nmWalk(27.0, LEFT)
        pause(50)
        rotate(Turn.LEFT, 2)
        nmWalk(50.0, FWD)

        // Shared tail of the Blue path.
        jump(holdMs = 100L)
        nmWalk(6.0, FWD)
        nmWalk(5.0, RIGHT)
        nmWalk(9.0, RIGHT, BACK)
        nmWalk(4.0, RIGHT)
        nmWalk(2.0, LEFT)
        nmWalk(21.0, BACK)
        nmWalk(3.4, FWD, LEFT)
        nmWalk(16.0, LEFT)
    }

    private fun red(): List<Cmd> = script {
        nmWalk(67.5, BACK, LEFT)
        rotate(Turn.RIGHT, 4)
        nmWalk(31.5, FWD)
        nmWalk(9.0, LEFT)
        nmWalk(9.0, BACK)
        nmWalk(58.5, LEFT)
        nmWalk(49.5, FWD)
        nmWalk(20.25, LEFT)
        rotate(Turn.RIGHT, 4)
        nmWalk(60.75, FWD)
        rotate(Turn.RIGHT, 2)
        nmWalk(9.0, BACK)
        nmWalk(15.75, BACK, RIGHT)
        nmWalk(29.7, LEFT)
        nmWalk(11.25, FWD)
        nmWalk(13.5, LEFT)
    }

    private fun mountain(): List<Cmd> = script {
        nmWalk(67.5, BACK, LEFT)
        rotate(Turn.RIGHT, 4)
        nmWalk(31.5, FWD)
        nmWalk(9.0, LEFT)
        nmWalk(9.0, BACK)
        nmWalk(58.5, LEFT)
        nmWalk(49.5, FWD)
        nmWalk(3.375, LEFT)
        nmWalk(36.0, FWD)
        nmWalk(54.0, RIGHT)
        nmWalk(54.0, BACK)
        nmWalk(58.5, RIGHT)
        nmWalk(15.75, FWD, LEFT)
        nmWalk(13.5, FWD)
        rotate(Turn.RIGHT, 4)
        nmWalk(27.0, RIGHT)
        nmWalk(18.0, BACK)
        nmWalk(27.0, RIGHT)
    }
}
