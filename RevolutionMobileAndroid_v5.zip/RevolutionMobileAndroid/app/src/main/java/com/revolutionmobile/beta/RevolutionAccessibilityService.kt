package com.revolutionmobile.beta

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityService.TakeScreenshotCallback
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.hardware.HardwareBuffer
import android.hardware.display.DisplayManager
import android.util.DisplayMetrics
import android.os.Build
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import com.revolutionmobile.beta.input.TouchStroke

/** Android-only bridge for screen capture and touch gestures. */
class RevolutionAccessibilityService : AccessibilityService() {
    private val mainHandler = Handler(Looper.getMainLooper())

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit
    override fun onInterrupt() = Unit

    fun captureScreen(callback: (Result<Bitmap>) -> Unit) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            callback(Result.failure(IllegalStateException("Для снимка экрана нужен Android 11 или новее.")))
            return
        }
        val executor = mainExecutor
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, executor, object : TakeScreenshotCallback {
                override fun onSuccess(screenshot: ScreenshotResult) {
                    val buffer: HardwareBuffer = screenshot.hardwareBuffer
                    try {
                        val hardwareBitmap = Bitmap.wrapHardwareBuffer(buffer, screenshot.colorSpace)
                        if (hardwareBitmap == null) {
                            callback(Result.failure(IllegalStateException("Android не вернул изображение.")))
                        } else {
                            val copy = hardwareBitmap.copy(Bitmap.Config.ARGB_8888, false)
                            hardwareBitmap.recycle()
                            if (copy == null) {
                                callback(Result.failure(IllegalStateException("Не удалось скопировать снимок.")))
                            } else {
                                callback(Result.success(copy))
                            }
                        }
                    } catch (error: Exception) {
                        callback(Result.failure(error))
                    } finally {
                        buffer.close()
                    }
                }

                override fun onFailure(errorCode: Int) {
                    callback(Result.failure(IllegalStateException("Не удалось снять экран. Код Android: $errorCode")))
                }
            })
        } catch (error: Exception) {
            callback(Result.failure(error))
        }
    }


    /** Dispatches several fingers in one gesture, needed for simultaneous joystick + camera input. */
    fun performMultiTouch(strokes: List<TouchStroke>, callback: ((Boolean) -> Unit)? = null) {
        if (strokes.isEmpty()) {
            callback?.invoke(false)
            return
        }
        try {
            val builder = GestureDescription.Builder()
            strokes.take(10).forEach { item ->
                val path = Path().apply {
                    moveTo(item.start.x.toFloat(), item.start.y.toFloat())
                    if (item.start == item.end) {
                        lineTo(item.end.x.toFloat() + 0.5f, item.end.y.toFloat() + 0.5f)
                    } else {
                        lineTo(item.end.x.toFloat(), item.end.y.toFloat())
                    }
                }
                builder.addStroke(
                    GestureDescription.StrokeDescription(
                        path,
                        item.delayMs.coerceAtLeast(0L),
                        item.durationMs.coerceIn(120L, 8_000L)
                    )
                )
            }
            val accepted = dispatchGesture(builder.build(), object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) { callback?.invoke(true) }
                override fun onCancelled(gestureDescription: GestureDescription?) { callback?.invoke(false) }
            }, null)
            if (!accepted) callback?.invoke(false)
        } catch (error: Exception) {
            callback?.invoke(false)
        }
    }

    /** Screen dimensions used by normalized touch profiles. */
    fun screenSizePx(): Pair<Int, Int> {
        // Реальный размер дисплея с учётом текущего поворота (displayMetrics сервиса может устареть).
        val display = getSystemService(DisplayManager::class.java)?.getDisplay(Display.DEFAULT_DISPLAY)
        if (display != null) {
            val metrics = DisplayMetrics()
            @Suppress("DEPRECATION")
            display.getRealMetrics(metrics)
            if (metrics.widthPixels > 0 && metrics.heightPixels > 0) {
                return metrics.widthPixels to metrics.heightPixels
            }
        }
        val fallback = resources.displayMetrics
        return fallback.widthPixels.coerceAtLeast(1) to fallback.heightPixels.coerceAtLeast(1)
    }

    /** Runs an action after a short delay so the user can switch to Roblox first. */
    fun postAfterDelay(delayMs: Long, action: () -> Unit) {
        mainHandler.postDelayed(action, delayMs.coerceAtLeast(0L))
    }

    /** Cancels delayed test commands that have not started yet. */
    fun cancelPendingActions() {
        mainHandler.removeCallbacksAndMessages(null)
    }

    fun tap(x: Float, y: Float, durationMs: Long = 70L, callback: ((Boolean) -> Unit)? = null) {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, durationMs.coerceAtLeast(1L)))
            .build()
        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) { callback?.invoke(true) }
            override fun onCancelled(gestureDescription: GestureDescription?) { callback?.invoke(false) }
        }, null)
    }

    fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long = 350L,
              callback: ((Boolean) -> Unit)? = null) {
        val path = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, durationMs.coerceAtLeast(1L)))
            .build()
        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) { callback?.invoke(true) }
            override fun onCancelled(gestureDescription: GestureDescription?) { callback?.invoke(false) }
        }, null)
    }

    companion object {
        @Volatile var instance: RevolutionAccessibilityService? = null
            private set
    }

    override fun onDestroy() {
        cancelPendingActions()
        if (instance === this) instance = null
        super.onDestroy()
    }
}
