package com.revolutionmobile.beta.input

import com.revolutionmobile.beta.RevolutionAccessibilityService
import com.revolutionmobile.beta.movement.GameButton
import com.revolutionmobile.beta.movement.StepRunner
import com.revolutionmobile.beta.movement.Turn

/** One finger path dispatched by Android AccessibilityService. */
data class TouchStroke(
    val start: PixelPoint,
    val end: PixelPoint,
    val durationMs: Long = 450L,
    val delayMs: Long = 0L
)

/**
 * Platform adapter for Revolution-style movement commands.
 * Desktop key/mouse commands are translated to Roblox mobile joystick and camera drags.
 */
class AndroidTouchController(
    private val serviceProvider: () -> RevolutionAccessibilityService?,
    private val profileProvider: () -> TouchProfile = { TouchProfile() }
) {
    /** Drags the joystick toward [direction] (screen space, y grows downward). */
    fun drive(direction: Vector2, durationMs: Long, callback: ((Boolean) -> Unit)? = null) {
        val service = serviceProvider() ?: run { callback?.invoke(false); return }
        val (width, height) = service.screenSizePx()
        val profile = profileProvider()
        val start = profile.joystickCenter.toPixels(width, height)
        val end = profile.joystickTarget(direction, width, height)
        service.performMultiTouch(listOf(TouchStroke(start, end, durationMs.coerceIn(120L, 8_000L))), callback)
    }

    /** Lets [StepRunner] drive this controller. */
    fun asMotionSink(): StepRunner.MotionSink =
        StepRunner.MotionSink { direction, durationMs, onDone -> drive(direction, durationMs, onDone) }

    fun move(key: MovementKey, durationMs: Long = 650L, callback: ((Boolean) -> Unit)? = null) {
        val service = serviceProvider() ?: run { callback?.invoke(false); return }
        val (width, height) = service.screenSizePx()
        val center = profileProvider().joystickCenter.toPixels(width, height)
        val target = profileProvider().joystickTarget(key.joystick, width, height)
        service.performMultiTouch(
            listOf(TouchStroke(center, target, durationMs.coerceIn(120L, 8_000L))),
            callback
        )
    }

    /** Moves the avatar and adjusts the camera with two simultaneous touch points. */
    fun moveAndLook(
        movement: MovementKey,
        camera: CameraKey,
        durationMs: Long = 650L,
        callback: ((Boolean) -> Unit)? = null
    ) {
        val service = serviceProvider() ?: run { callback?.invoke(false); return }
        val (width, height) = service.screenSizePx()
        val profile = profileProvider()
        val joystickStart = profile.joystickCenter.toPixels(width, height)
        val joystickEnd = profile.joystickTarget(movement.joystick, width, height)
        val cameraStart = profile.cameraCenter.toPixels(width, height)
        val cameraEnd = profile.cameraTarget(camera.delta, width, height)
        val duration = durationMs.coerceIn(120L, 8_000L)
        service.performMultiTouch(
            listOf(
                TouchStroke(joystickStart, joystickEnd, duration),
                TouchStroke(cameraStart, cameraEnd, duration)
            ),
            callback
        )
    }

    fun look(key: CameraKey, durationMs: Long = 450L, callback: ((Boolean) -> Unit)? = null) {
        val service = serviceProvider() ?: run { callback?.invoke(false); return }
        val (width, height) = service.screenSizePx()
        val profile = profileProvider()
        val start = profile.cameraCenter.toPixels(width, height)
        val end = profile.cameraTarget(key.delta, width, height)
        service.performMultiTouch(
            listOf(TouchStroke(start, end, durationMs.coerceIn(120L, 8_000L))),
            callback
        )
    }

    /** Presses jump for [holdMs]. If [moving] is set, the joystick is held in that direction during the press. */
    fun jump(moving: Vector2?, holdMs: Long, callback: ((Boolean) -> Unit)? = null) {
        val service = serviceProvider() ?: run { callback?.invoke(false); return }
        val (width, height) = service.screenSizePx()
        val profile = profileProvider()
        val duration = holdMs.coerceIn(120L, 8_000L)
        val button = profile.jumpButton.toPixels(width, height)
        val strokes = mutableListOf(TouchStroke(button, button, duration))
        if (moving != null) {
            strokes += TouchStroke(
                profile.joystickCenter.toPixels(width, height),
                profile.joystickTarget(moving, width, height),
                duration
            )
        }
        service.performMultiTouch(strokes, callback)
    }

    /** Presses a game button (currently only INTERACT) for [holdMs]. */
    fun tap(button: GameButton, holdMs: Long, callback: ((Boolean) -> Unit)? = null) {
        val service = serviceProvider() ?: run { callback?.invoke(false); return }
        val (width, height) = service.screenSizePx()
        val profile = profileProvider()
        val point = when (button) {
            GameButton.INTERACT -> profile.interactButton
        }.toPixels(width, height)
        service.performMultiTouch(
            listOf(TouchStroke(point, point, holdMs.coerceIn(120L, 8_000L))),
            callback
        )
    }

    /** Lets [StepRunner] send jump, camera-turn and button gestures. */
    fun asActionSink(): StepRunner.ActionSink = object : StepRunner.ActionSink {
        override fun jump(moving: Vector2?, holdMs: Long, onDone: (Boolean) -> Unit) =
            this@AndroidTouchController.jump(moving, holdMs, onDone)

        override fun turnCamera(turn: Turn, onDone: (Boolean) -> Unit) =
            look(
                if (turn == Turn.LEFT) CameraKey.ROTATE_LEFT else CameraKey.ROTATE_RIGHT,
                CAMERA_SWIPE_MS,
                onDone
            )

        override fun tap(button: GameButton, holdMs: Long, onDone: (Boolean) -> Unit) =
            this@AndroidTouchController.tap(button, holdMs, onDone)
    }

    companion object {
        /** One camera turn step is one swipe. Calibrate the distance in the profile, not here. */
        const val CAMERA_SWIPE_MS = 150L
    }
}
