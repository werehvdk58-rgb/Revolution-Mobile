/*
 * Revolution Mobile Beta — GPL-3.0-or-later.
 * Port of Natro Macro's paths/wf-pinetree.ahk, both branches
 * (https://github.com/NatroTeam/NatroMacro), Copyright © Natro Team, GNU GPL v3.
 * See NOTICE and LICENSE.
 *
 * Starts in the Pine Tree field and walks back to the hive. The hive slot and the walk/cannon
 * choice come from [RuntimeContext]; they are not part of this route's identity.
 * Natro's Shift presses (shift-lock for aiming) are skipped: mobile Roblox has no shift lock toggle.
 */
package com.revolutionmobile.beta.movement.routes

import com.revolutionmobile.beta.config.MoveMethod
import com.revolutionmobile.beta.movement.Cmd
import com.revolutionmobile.beta.movement.Dir.BACK
import com.revolutionmobile.beta.movement.Dir.FWD
import com.revolutionmobile.beta.movement.Dir.LEFT
import com.revolutionmobile.beta.movement.Dir.RIGHT
import com.revolutionmobile.beta.movement.GameButton
import com.revolutionmobile.beta.movement.RuntimeContext
import com.revolutionmobile.beta.movement.Script
import com.revolutionmobile.beta.movement.Turn
import com.revolutionmobile.beta.movement.script

class WfPinetreeRoute : Route {
    override val name: String = "wf-pinetree"

    override fun supports(ctx: RuntimeContext): Boolean = true

    override fun build(ctx: RuntimeContext): List<Cmd> =
        if (usesWalkBranch(ctx)) walkBranch(ctx) else cannonBranch(ctx)

    private fun walkBranch(ctx: RuntimeContext): List<Cmd> = script {
        nmWalk(31.0, FWD)
        nmWalk(75.0, RIGHT)
        rotate(Turn.LEFT, 4)
        pause(50)
        nmWalk(20.0, FWD)
        nmWalk(3.0, FWD, LEFT)
        nmWalk(18.0, FWD)
        nmWalk(6.0, FWD, RIGHT)
        nmWalk(10.0, RIGHT)
        nmWalk(2.0, LEFT)

        // Forward, jump while still moving forward, then keep going.
        down(FWD)
        walk(6.0)
        jump(holdMs = 200L)
        walk(108.0)
        up(FWD)

        returnToHive(ctx)
    }

    private fun cannonBranch(ctx: RuntimeContext): List<Cmd> = script {
        nmWalk(30.0, FWD)
        nmWalk(25.0, LEFT)
        nmWalk(2.0, FWD)
        nmWalk(30.0, BACK)
        nmWalk(23.0, BACK, RIGHT)
        nmWalk(7.0, BACK)
        nmWalk(5.0, RIGHT)
        nmWalk(12.0, BACK)
        jump(holdMs = 100L)
        nmWalk(9.5, BACK)
        nmWalk(4.0, RIGHT)
        pause(200)

        // Cannon: aim with four camera turns, then enter with E.
        repeat(4) {
            rotate(Turn.RIGHT, 1)
            pause(50)
        }
        pause(100)
        tap(GameButton.INTERACT, holdMs = 10L)
        pause(10)

        // Glider: two short jumps, a long wait, then one jump to open it.
        repeat(2) {
            jump(holdMs = 200L)
            pause(200)
        }
        pause(3800)
        jump(holdMs = 100L)
        pause(500)

        // Back to the hive from the glider landing.
        nmWalk(3.3, BACK)
        nmWalk(3.0, RIGHT)
        nmWalk(1.0, FWD)
        nmWalk(32.0, RIGHT)
        nmWalk(5.0, FWD)
        nmWalk(4.0, BACK)
    }

    /** Natro's walk-branch tail: the hive slot decides how far back to walk. */
    private fun Script.returnToHive(ctx: RuntimeContext) {
        when (ctx.hiveSlot) {
            3 -> nmWalk(2.7, BACK)
            else -> {
                nmWalk(1.5, BACK)
                nmWalk(35.0, RIGHT)
                nmWalk(2.7, BACK)
            }
        }
    }

    companion object {
        /** Natro: HiveBees < 25 always uses the walk branch. */
        const val WALK_BRANCH_BEE_LIMIT = 25

        fun usesWalkBranch(ctx: RuntimeContext): Boolean =
            ctx.hiveBees < WALK_BRANCH_BEE_LIMIT || ctx.moveMethod == MoveMethod.WALK
    }
}
