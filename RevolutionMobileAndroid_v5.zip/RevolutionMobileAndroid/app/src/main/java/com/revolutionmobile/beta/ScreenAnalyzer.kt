package com.revolutionmobile.beta

import android.graphics.Bitmap

/** Small, deterministic frame diagnostics. Game-specific recognition is deliberately isolated here. */
object ScreenAnalyzer {
    data class FrameInfo(
        val width: Int,
        val height: Int,
        val averageRed: Int,
        val averageGreen: Int,
        val averageBlue: Int
    ) {
        fun asText(): String = "Экран: ${width}×${height}\nСредний RGB: $averageRed, $averageGreen, $averageBlue"
    }

    fun inspect(bitmap: Bitmap): FrameInfo {
        val width = bitmap.width
        val height = bitmap.height
        val stepX = (width / 64).coerceAtLeast(1)
        val stepY = (height / 64).coerceAtLeast(1)
        var red = 0L; var green = 0L; var blue = 0L; var count = 0L
        var y = 0
        while (y < height) {
            var x = 0
            while (x < width) {
                val pixel = bitmap.getPixel(x, y)
                red += (pixel shr 16) and 0xff
                green += (pixel shr 8) and 0xff
                blue += pixel and 0xff
                count++
                x += stepX
            }
            y += stepY
        }
        val divisor = count.coerceAtLeast(1L)
        return FrameInfo(width, height, (red / divisor).toInt(), (green / divisor).toInt(), (blue / divisor).toInt())
    }
}
