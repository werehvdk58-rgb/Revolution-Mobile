/*
 * Revolution Mobile Beta — GPL-3.0-or-later.
 * Runs Natro-style command lists through a touch sink. Android-independent, unit-testable.
 */
package com.revolutionmobile.beta.movement

import com.revolutionmobile.beta.input.Vector2

/**
 * Down/Up change the set of held directions. Walk moves the joystick toward the sum of the
 * held directions for the time given by [MoveSpeed]. With no direction held, Walk only waits,
 * as in Natro (the character stands still while time passes).
 */
class StepRunner(
    private val motion: MotionSink,
    private val scheduler: Scheduler,
    private val actions: ActionSink = ActionSink.Unsupported,
    private val speedFor: (hasteCap: Int) -> Double = { cap ->
        MoveSpeed.studsPerSecond(MoveSpeed.DEFAULT_BASE_MOVESPEED, MoveBuffs(), cap)
    }
) {
    fun interface MotionSink {
        /** Drags the joystick toward [direction] for [durationMs]; calls [onDone] with true if it completed. */
        fun drive(direction: Vector2, durationMs: Long, onDone: (Boolean) -> Unit)
    }

    /** Jump and camera gestures. Kept apart from [MotionSink] so the walk timing stays unchanged. */
    interface ActionSink {
        /** Presses jump for [holdMs]. [moving] is the joystick vector held at the same time, or null. */
        fun jump(moving: Vector2?, holdMs: Long, onDone: (Boolean) -> Unit)

        /** One camera-turn swipe. */
        fun turnCamera(turn: Turn, onDone: (Boolean) -> Unit)

        /** Presses a game button for [holdMs]. */
        fun tap(button: GameButton, holdMs: Long, onDone: (Boolean) -> Unit)

        /** Used when no Android bridge is attached: every action reports failure. */
        object Unsupported : ActionSink {
            override fun jump(moving: Vector2?, holdMs: Long, onDone: (Boolean) -> Unit) = onDone(false)
            override fun turnCamera(turn: Turn, onDone: (Boolean) -> Unit) = onDone(false)
            override fun tap(button: GameButton, holdMs: Long, onDone: (Boolean) -> Unit) = onDone(false)
        }
    }

    interface Scheduler {
        fun postDelayed(delayMs: Long, action: () -> Unit)
        fun cancelAll()
    }

    private val held = mutableSetOf<Dir>()
    private var generation = 0

    var running: Boolean = false
        private set

    val heldDirections: Set<Dir> get() = held.toSet()

    /** Starts [commands]. [onFinished] gets true at the end, false if a gesture failed. Not called after [stop]. */
    fun start(commands: List<Cmd>, onFinished: (Boolean) -> Unit = {}) {
        stop()
        val gen = generation
        running = true
        run(commands, 0, gen, onFinished)
    }

    /** Stops after the current gesture. No further gestures are sent. */
    fun stop() {
        generation++
        running = false
        held.clear()
        scheduler.cancelAll()
    }

    private fun fail(onFinished: (Boolean) -> Unit) {
        running = false
        held.clear()
        onFinished(false)
    }

    private fun run(commands: List<Cmd>, start: Int, gen: Int, onFinished: (Boolean) -> Unit) {
        var i = start
        while (i < commands.size) {
            if (gen != generation) return
            when (val cmd = commands[i]) {
                is Cmd.Down -> held += cmd.dir
                is Cmd.Up -> held -= cmd.dir
                is Cmd.Sleep -> {
                    val next = i + 1
                    scheduler.postDelayed(cmd.ms.coerceAtLeast(0L)) { run(commands, next, gen, onFinished) }
                    return
                }
                is Cmd.Walk -> {
                    val next = i + 1
                    walk(cmd, gen) { ok ->
                        if (gen != generation) return@walk
                        if (ok) run(commands, next, gen, onFinished) else fail(onFinished)
                    }
                    return
                }
                is Cmd.Jump -> {
                    val next = i + 1
                    actions.jump(heldDirection(), cmd.holdMs) { ok ->
                        if (gen != generation) return@jump
                        if (ok) run(commands, next, gen, onFinished) else fail(onFinished)
                    }
                    return
                }
                is Cmd.Rotate -> {
                    val next = i + 1
                    turnSteps(cmd.turn, cmd.steps, gen) { ok ->
                        if (gen != generation) return@turnSteps
                        if (ok) run(commands, next, gen, onFinished) else fail(onFinished)
                    }
                    return
                }
                is Cmd.Tap -> {
                    val next = i + 1
                    actions.tap(cmd.button, cmd.holdMs) { ok ->
                        if (gen != generation) return@tap
                        if (ok) run(commands, next, gen, onFinished) else fail(onFinished)
                    }
                    return
                }
            }
            i++
        }
        if (gen == generation) {
            running = false
            held.clear()
            onFinished(true)
        }
    }

    private fun walk(cmd: Cmd.Walk, gen: Int, onDone: (Boolean) -> Unit) {
        val total = MoveSpeed.walkMillis(cmd.tiles, speedFor(cmd.hasteCap))
        if (total <= 0L) {
            onDone(true)
            return
        }
        val direction = heldDirection()
        if (direction == null) {
            scheduler.postDelayed(total) { onDone(true) }
            return
        }
        driveChunks(direction, total, gen, onDone)
    }

    private fun driveChunks(direction: Vector2, remaining: Long, gen: Int, onDone: (Boolean) -> Unit) {
        if (gen != generation) return
        if (remaining <= 0L) {
            onDone(true)
            return
        }
        val chunk = minOf(remaining, MAX_CHUNK_MS)
        motion.drive(direction, chunk) { ok ->
            if (ok) driveChunks(direction, remaining - chunk, gen, onDone) else onDone(false)
        }
    }

    /** Sends [remaining] camera swipes one after another. */
    private fun turnSteps(turn: Turn, remaining: Int, gen: Int, onDone: (Boolean) -> Unit) {
        if (gen != generation) return
        if (remaining <= 0) {
            onDone(true)
            return
        }
        actions.turnCamera(turn) { ok ->
            if (ok) turnSteps(turn, remaining - 1, gen, onDone) else onDone(false)
        }
    }

    private fun heldDirection(): Vector2? {
        if (held.isEmpty()) return null
        var x = 0f
        var y = 0f
        for (d in held) {
            x += d.vx
            y += d.vy
        }
        return if (x == 0f && y == 0f) null else Vector2(x, y)
    }

    companion object {
        /** Android caps a stroke at 8 s; stay below it. */
        const val MAX_CHUNK_MS = 7_500L
    }
}
