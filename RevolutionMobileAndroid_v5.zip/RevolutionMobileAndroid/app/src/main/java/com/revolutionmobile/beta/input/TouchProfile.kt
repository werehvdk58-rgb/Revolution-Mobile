package com.revolutionmobile.beta.input

/** A screen point stored as fractions so the profile works across resolutions. */
data class NormalizedPoint(val x: Float, val y: Float) {
    init {
        require(x in 0f..1f) { "x must be between 0 and 1" }
        require(y in 0f..1f) { "y must be between 0 and 1" }
    }

    fun toPixels(width: Int, height: Int): PixelPoint {
        require(width > 0 && height > 0) { "Screen dimensions must be positive" }
        return PixelPoint((x * width).toInt().coerceIn(0, width - 1),
            (y * height).toInt().coerceIn(0, height - 1))
    }
}

data class PixelPoint(val x: Int, val y: Int)
data class Vector2(val x: Float, val y: Float) {
    fun normalized(): Vector2 {
        val length = kotlin.math.sqrt(x * x + y * y)
        return if (length == 0f) this else Vector2(x / length, y / length)
    }
}

/**
 * Android touch layout. These are provisional Roblox mobile defaults, not values
 * copied from Revolution. Users will be able to calibrate them in a later UI step.
 */
data class TouchProfile(
    val joystickCenter: NormalizedPoint = NormalizedPoint(0.145f, 0.795f),
    val joystickRadiusFraction: Float = 0.095f,
    val cameraCenter: NormalizedPoint = NormalizedPoint(0.80f, 0.70f),
    val cameraDragFraction: Float = 0.17f,
    /** Jump button. Provisional: placed right of the camera zone, not verified on a Roblox HUD. */
    val jumpButton: NormalizedPoint = NormalizedPoint(0.91f, 0.84f),
    /** Interact (Natro's E) button. Provisional, not verified on a Roblox HUD. */
    val interactButton: NormalizedPoint = NormalizedPoint(0.90f, 0.60f)
) {
    init {
        require(joystickRadiusFraction in 0.02f..0.25f)
        require(cameraDragFraction in 0.02f..0.40f)
    }

    fun joystickTarget(direction: Vector2, width: Int, height: Int): PixelPoint {
        require(width > 0 && height > 0)
        val vector = direction.normalized()
        val center = joystickCenter.toPixels(width, height)
        val radius = (width * joystickRadiusFraction).toInt().coerceAtLeast(1)
        return PixelPoint(
            (center.x + vector.x * radius).toInt().coerceIn(0, width - 1),
            (center.y + vector.y * radius).toInt().coerceIn(0, height - 1)
        )
    }

    fun cameraTarget(delta: Vector2, width: Int, height: Int): PixelPoint {
        require(width > 0 && height > 0)
        val center = cameraCenter.toPixels(width, height)
        val vector = delta.normalized()
        val dx = (width * cameraDragFraction * vector.x).toInt()
        val dy = (height * cameraDragFraction * vector.y).toInt()
        return PixelPoint((center.x + dx).coerceIn(0, width - 1),
            (center.y + dy).coerceIn(0, height - 1))
    }
}

/** Direction names correspond to the movement keys documented by Revolution's Go API. */
enum class MovementKey(val joystick: Vector2) {
    FORWARD(Vector2(0f, -1f)),
    BACKWARD(Vector2(0f, 1f)),
    LEFT(Vector2(-1f, 0f)),
    RIGHT(Vector2(1f, 0f)),
    FORWARD_LEFT(Vector2(-1f, -1f)),
    FORWARD_RIGHT(Vector2(1f, -1f)),
    BACKWARD_LEFT(Vector2(-1f, 1f)),
    BACKWARD_RIGHT(Vector2(1f, 1f))
}

enum class CameraKey(val delta: Vector2) {
    ROTATE_LEFT(Vector2(-1f, 0f)),
    ROTATE_RIGHT(Vector2(1f, 0f)),
    ROTATE_UP(Vector2(0f, -1f)),
    ROTATE_DOWN(Vector2(0f, 1f))
}
