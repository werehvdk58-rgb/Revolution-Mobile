/*
 * Revolution Mobile Beta — GPL-3.0-or-later.
 * User settings chosen inside the app. Routes never read these from file names;
 * they receive a RuntimeContext built from this model.
 */
package com.revolutionmobile.beta.config

import com.revolutionmobile.beta.movement.MoveSpeed

/** Movement method chosen by the user. Natro's "walk" and "cannon" values. */
enum class MoveMethod(val label: String) {
    WALK("Ходьба"),
    CANNON("Пушка")
}

/**
 * Persistent settings. Defaults are the values a new user starts with.
 *
 * @property hiveSlot hive number, 1..6 (Natro's HiveSlot).
 * @property moveMethod walk or cannon (Natro's MoveMethod).
 * @property hiveBees bees in the hive, 0..50 (Natro's HiveBees). Manual until screen detection exists.
 * @property baseMoveSpeed base walk speed in studs per second, without buffs.
 */
data class AppConfig(
    val hiveSlot: Int = 1,
    val moveMethod: MoveMethod = MoveMethod.WALK,
    val hiveBees: Int = 50,
    val baseMoveSpeed: Int = MoveSpeed.DEFAULT_BASE_MOVESPEED
) {
    init {
        require(hiveSlot in MIN_HIVE_SLOT..MAX_HIVE_SLOT) { "hiveSlot must be $MIN_HIVE_SLOT..$MAX_HIVE_SLOT" }
        require(hiveBees in 0..MAX_HIVE_BEES) { "hiveBees must be 0..$MAX_HIVE_BEES" }
        require(baseMoveSpeed in MIN_BASE_SPEED..MAX_BASE_SPEED) { "baseMoveSpeed must be $MIN_BASE_SPEED..$MAX_BASE_SPEED" }
    }

    companion object {
        const val MIN_HIVE_SLOT = 1
        const val MAX_HIVE_SLOT = 6
        const val MAX_HIVE_BEES = 50
        const val MIN_BASE_SPEED = 1
        const val MAX_BASE_SPEED = 100
    }
}
