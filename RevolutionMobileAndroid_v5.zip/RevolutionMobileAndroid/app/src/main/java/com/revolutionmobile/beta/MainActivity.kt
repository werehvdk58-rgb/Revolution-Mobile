package com.revolutionmobile.beta

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import com.revolutionmobile.beta.config.AppConfig
import com.revolutionmobile.beta.config.AppConfigStore
import com.revolutionmobile.beta.config.MoveMethod
import com.revolutionmobile.beta.input.AndroidTouchController
import com.revolutionmobile.beta.input.CameraKey
import com.revolutionmobile.beta.input.MovementKey
import com.revolutionmobile.beta.input.TouchProfileStore
import com.revolutionmobile.beta.movement.Cmd
import com.revolutionmobile.beta.movement.GatherPattern
import com.revolutionmobile.beta.movement.PatternContext
import com.revolutionmobile.beta.movement.RuntimeContext
import com.revolutionmobile.beta.movement.StepRunner
import com.revolutionmobile.beta.movement.routes.Route
import com.revolutionmobile.beta.movement.routes.TunnelBear
import com.revolutionmobile.beta.movement.routes.TunnelBearRoute
import com.revolutionmobile.beta.movement.routes.WfPinetreeRoute
import com.revolutionmobile.beta.movement.script

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var preview: ImageView
    private lateinit var touchProfileStore: TouchProfileStore
    private lateinit var configStore: AppConfigStore
    private lateinit var hiveSpinner: Spinner
    private lateinit var methodSpinner: Spinner
    private lateinit var bearSpinner: Spinner
    private lateinit var beesInput: EditText
    private lateinit var speedInput: EditText
    private var stepRunner: StepRunner? = null
    private var selectedPattern = GatherPattern.SNAKE

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        touchProfileStore = TouchProfileStore(this)
        configStore = AppConfigStore(this)
        buildScreen()
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(20))
            setBackgroundColor(Color.rgb(18, 18, 29))
        }
        val scroll = ScrollView(this).apply { addView(root) }
        val title = TextView(this).apply {
            text = "REVOLUTION\nMOBILE BETA"
            textSize = 26f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, dp(16))
        }
        root.addView(title, matchWrap())
        status = TextView(this).apply {
            textSize = 15f
            setTextColor(Color.rgb(210, 210, 225))
            setPadding(dp(12), dp(14), dp(12), dp(14))
            setBackgroundColor(Color.rgb(35, 35, 52))
        }
        root.addView(status, matchWrap())
        root.addView(makeButton("1. Включить службу управления") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(makeButton("2. Проверить экран Bee Swarm") { scanScreen() })
        root.addView(makeButton("ОТМЕНИТЬ ожидающие тесты") {
            stepRunner?.stop()
            RevolutionAccessibilityService.instance?.cancelPendingActions()
            status.text = "Отложенные тестовые действия отменены. Уже начавшийся жест эта кнопка не прерывает."
        })

        root.addView(sectionTitle("Настройки"))
        val config = configStore.load()
        hiveSpinner = spinner((AppConfig.MIN_HIVE_SLOT..AppConfig.MAX_HIVE_SLOT).map { "Улей $it" }, config.hiveSlot - AppConfig.MIN_HIVE_SLOT)
        root.addView(hiveSpinner, matchWrap().apply { topMargin = dp(8) })
        methodSpinner = spinner(MoveMethod.entries.map { it.label }, MoveMethod.entries.indexOf(config.moveMethod))
        root.addView(methodSpinner, matchWrap().apply { topMargin = dp(8) })
        beesInput = numberField("Пчёлы в улье (0–${AppConfig.MAX_HIVE_BEES})", config.hiveBees)
        root.addView(beesInput, matchWrap().apply { topMargin = dp(8) })
        speedInput = numberField("Базовая скорость (${AppConfig.MIN_BASE_SPEED}–${AppConfig.MAX_BASE_SPEED})", config.baseMoveSpeed)
        root.addView(speedInput, matchWrap().apply { topMargin = dp(8) })
        root.addView(makeButton("Сохранить настройки") { saveSettings() })

        root.addView(sectionTitle("Маршруты (ходьба)"))
        bearSpinner = spinner(TunnelBear.entries.map { "Tunnel Bear: ${it.label}" }, 1)
        root.addView(bearSpinner, matchWrap().apply { topMargin = dp(8) })
        root.addView(makeButton("Тест: Tunnel Bear (через 5 с)") {
            runRoute(TunnelBearRoute(TunnelBear.entries[bearSpinner.selectedItemPosition]))
        })
        root.addView(makeButton("Тест: wf-pinetree (через 5 с)") { runRoute(WfPinetreeRoute()) })
        root.addView(makeButton("Тест: прыжок (через 5 с)") {
            startRun("Прыжок", script { jump(holdMs = 200L) }, currentContext())
        })

        root.addView(sectionTitle("Отдельные движения"))
        root.addView(makeButton("Тест движения вперёд (через 5 секунд)") { runMovementTest() })
        root.addView(makeButton("Тест поворота камеры вправо (через 5 секунд)") { runCameraTest() })
        val picker = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, GatherPattern.entries.map { it.label })
            setSelection(GatherPattern.entries.indexOf(selectedPattern))
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                    selectedPattern = GatherPattern.entries[position]
                }
                override fun onNothingSelected(parent: AdapterView<*>?) = Unit
            }
        }
        root.addView(picker, matchWrap().apply { topMargin = dp(10) })
        root.addView(makeButton("Тест выбранного паттерна (через 5 секунд)") { runPatternTest(selectedPattern) })
        preview = ImageView(this).apply {
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(Color.rgb(28, 28, 40))
        }
        root.addView(preview, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(220)).apply {
            topMargin = dp(12)
        })
        val note = TextView(this).apply {
            text = "Ранний Android-портовый каркас. wf-pinetree перенесён полностью (ходьба и пушка). " +
                "Tunnel Bear — только режим «Ходьба»: переход от улья к рампе и пушка пока не перенесены, " +
                "поставь персонажа на рампу вручную. Точки касания (джойстик, камера, прыжок, E) предварительные — " +
                "сначала проверь их в безопасном месте."
            textSize = 13f
            setTextColor(Color.LTGRAY)
            setPadding(0, dp(16), 0, dp(8))
        }
        root.addView(note, matchWrap())
        setContentView(scroll)
        refreshStatus()
    }

    private fun currentContext(): RuntimeContext = RuntimeContext(configStore.load())

    private fun saveSettings() {
        try {
            val config = AppConfig(
                hiveSlot = hiveSpinner.selectedItemPosition + AppConfig.MIN_HIVE_SLOT,
                moveMethod = MoveMethod.entries[methodSpinner.selectedItemPosition],
                hiveBees = beesInput.text.toString().toIntOrNull()
                    ?: throw IllegalArgumentException("пчёлы: введи целое число"),
                baseMoveSpeed = speedInput.text.toString().toIntOrNull()
                    ?: throw IllegalArgumentException("скорость: введи целое число")
            )
            configStore.save(config)
            status.text = "Настройки сохранены: улей ${config.hiveSlot}, ${config.moveMethod.label.lowercase()}, " +
                "пчёл ${config.hiveBees}, скорость ${config.baseMoveSpeed}."
        } catch (error: IllegalArgumentException) {
            status.text = "Настройки не сохранены: ${error.message}"
        }
    }

    private fun makeButton(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label
        isAllCaps = false
        setOnClickListener { action() }
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .apply { topMargin = dp(10) }
    }

    private fun sectionTitle(label: String): TextView = TextView(this).apply {
        text = label
        textSize = 17f
        setTextColor(Color.rgb(255, 214, 102))
        setPadding(0, dp(22), 0, 0)
    }

    private fun spinner(items: List<String>, selected: Int): Spinner = Spinner(this).apply {
        adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, items)
        setSelection(selected.coerceIn(0, items.size - 1))
    }

    private fun numberField(hint: String, value: Int): EditText = EditText(this).apply {
        setText(value.toString())
        this.hint = hint
        setTextColor(Color.WHITE)
        setHintTextColor(Color.GRAY)
        inputType = android.text.InputType.TYPE_CLASS_NUMBER
    }

    private fun scanScreen() {
        val service = RevolutionAccessibilityService.instance
        if (service == null) {
            status.text = "Служба выключена. Сначала нажми «Включить службу управления» и разреши Revolution Mobile Beta."
            return
        }
        status.text = "Сканирую экран…"
        service.captureScreen { result ->
            result.onSuccess { bitmap: Bitmap ->
                preview.setImageBitmap(bitmap)
                val info = ScreenAnalyzer.inspect(bitmap)
                status.text = "Снимок получен.\n${info.asText()}\nСледующий этап — детектор игровых элементов."
            }.onFailure { error ->
                status.text = "Ошибка захвата: ${error.message ?: "неизвестная ошибка"}"
            }
        }
    }

    private fun runMovementTest() {
        val service = RevolutionAccessibilityService.instance
        if (service == null) {
            status.text = "Сначала включи службу управления."
            return
        }
        status.text = "Через 5 секунд будет короткое касание джойстика. Быстро переключись в Roblox."
        val controller = AndroidTouchController({ RevolutionAccessibilityService.instance }) { touchProfileStore.load() }
        service.postAfterDelay(5_000L) {
            controller.move(MovementKey.FORWARD, 650L) { completed ->
                status.text = if (completed) "Тест движения отправлен. Проверь, двинулся ли персонаж." else "Тест движения не выполнен. Проверь службу и положение джойстика."
            }
        }
    }

    private fun runCameraTest() {
        val service = RevolutionAccessibilityService.instance
        if (service == null) {
            status.text = "Сначала включи службу управления."
            return
        }
        status.text = "Через 5 секунд будет короткий свайп камеры. Переключись в Roblox."
        val controller = AndroidTouchController({ RevolutionAccessibilityService.instance }) { touchProfileStore.load() }
        service.postAfterDelay(5_000L) {
            controller.look(CameraKey.ROTATE_RIGHT, 500L) { completed ->
                status.text = if (completed) "Свайп камеры отправлен. Проверь результат." else "Свайп не выполнен. Проверь службу."
            }
        }
    }

    /** Builds the route with the saved settings. Routes that do not support those settings are refused here. */
    private fun runRoute(route: Route) {
        val ctx = currentContext()
        if (!route.supports(ctx)) {
            status.text = "${route.name} для режима «${ctx.moveMethod.label}» ещё не перенесён. Выбери «Ходьба»."
            return
        }
        startRun(route.name, route.build(ctx), ctx)
    }

    /** Runs [commands] after a 5 s delay so the user can switch to Roblox. Speed comes from [ctx]. */
    private fun startRun(label: String, commands: List<Cmd>, ctx: RuntimeContext) {
        val service = RevolutionAccessibilityService.instance
        if (service == null) {
            status.text = "Сначала включи службу управления."
            return
        }
        val controller = AndroidTouchController({ RevolutionAccessibilityService.instance }) { touchProfileStore.load() }
        val scheduler = object : StepRunner.Scheduler {
            override fun postDelayed(delayMs: Long, action: () -> Unit) = service.postAfterDelay(delayMs, action)
            override fun cancelAll() = service.cancelPendingActions()
        }
        val runner = StepRunner(controller.asMotionSink(), scheduler, controller.asActionSink()) { cap ->
            ctx.studsPerSecond(cap)
        }
        stepRunner?.stop()
        stepRunner = runner
        status.text = "Через 5 секунд начнётся «$label». Переключись в Roblox. Остановка — «ОТМЕНИТЬ»."
        service.postAfterDelay(5_000L) {
            status.text = "«$label» выполняется…"
            runner.start(commands) { ok ->
                status.text = if (ok) "«$label» завершён. Проверь, как прошёл персонаж." else "«$label» прерван: жест не выполнен."
            }
        }
    }

    /** Runs a Natro gathering pattern (GPL-3.0 port), medium size, one repetition, speed from settings. */
    private fun runPatternTest(pattern: GatherPattern) {
        startRun(pattern.label, pattern.build(PatternContext(size = 1.0, reps = 1)), currentContext())
    }

    private fun refreshStatus() {
        status.text = if (RevolutionAccessibilityService.instance != null) {
            "Служба управления включена. Можно проверять захват экрана."
        } else {
            "Служба управления пока выключена. Включи её кнопкой ниже."
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
}
