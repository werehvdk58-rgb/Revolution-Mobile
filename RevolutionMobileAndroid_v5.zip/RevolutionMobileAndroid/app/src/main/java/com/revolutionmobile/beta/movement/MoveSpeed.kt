/*
 * Revolution Mobile Beta — GPL-3.0-or-later.
 *
 * The movement-speed formula and the "4 studs per tile" walking model below are ported
 * from Natro Macro's lib/Walk.ahk (https://github.com/NatroTeam/NatroMacro),
 * Copyright © Natro Team, licensed under GNU GPL v3. See NOTICE and LICENSE.
 */
package com.revolutionmobile.beta.movement

/** Buffs that change walking speed. Natro detects them from buff icons; here they are set by the caller. */
data class MoveBuffs(
    /** Haste stack count (0 = no haste, 1 = haste without multiplier, up to 10). */
    val haste: Int = 0,
    val coconutHaste: Boolean = false,
    val hastePlus: Boolean = false,
    val bear: Boolean = false,
    val oil: Boolean = false,
    val smoothie: Boolean = false,
    val hastyGuard: Boolean = false,
    val giftedHasty: Boolean = false
)

object MoveSpeed {
    /** Natro's default for MoveSpeedNum: in-game walk speed without buffs. */
    const val DEFAULT_BASE_MOVESPEED = 28
    const val STUDS_PER_TILE = 4.0

    /** Natro starts every walk with a credit of 1/8 stud (freq // 8 in Walk.ahk). */
    private const val HEAD_START_STUDS = 0.125

    /** Studs per second. Same formula as DetectMovespeed() in Natro's Walk.ahk. */
    fun studsPerSecond(base: Int, buffs: MoveBuffs = MoveBuffs(), hasteCap: Int = 0): Double {
        val flat = base + (if (buffs.coconutHaste) 10 else 0) + (if (buffs.bear) 4 else 0)
        return flat.toDouble() *
            (if (buffs.hastyGuard) 1.1 else 1.0) *
            (if (buffs.giftedHasty) 1.15 else 1.0) *
            (1.0 + maxOf(0, buffs.haste - hasteCap) * 0.1) *
            (if (buffs.hastePlus) 2.0 else 1.0) *
            (if (buffs.oil) 1.2 else 1.0) *
            (if (buffs.smoothie) 1.25 else 1.0)
    }

    /** Seconds needed to walk [tiles] tiles at [studsPerSecond]. */
    fun walkSeconds(tiles: Double, studsPerSecond: Double): Double {
        require(studsPerSecond > 0.0) { "Speed must be positive" }
        return maxOf(0.0, tiles * STUDS_PER_TILE - HEAD_START_STUDS) / studsPerSecond
    }

    fun walkMillis(tiles: Double, studsPerSecond: Double): Long =
        Math.round(walkSeconds(tiles, studsPerSecond) * 1000.0)
}
