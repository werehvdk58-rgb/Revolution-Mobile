package com.revolutionmobile.beta.input

import android.content.Context

/** Stores calibration points in normalized coordinates (0.0–1.0). */
class TouchProfileStore(context: Context) {
    private val preferences = context.getSharedPreferences("revolution_touch_profile", Context.MODE_PRIVATE)

    /** Если сохранённые значения повреждены, возвращает профиль по умолчанию вместо падения. */
    fun load(): TouchProfile = try {
        readProfile()
    } catch (error: IllegalArgumentException) {
        TouchProfile()
    }

    private fun readProfile(): TouchProfile = TouchProfile(
        joystickCenter = NormalizedPoint(
            preferences.getFloat(KEY_JOYSTICK_X, 0.145f),
            preferences.getFloat(KEY_JOYSTICK_Y, 0.795f)
        ),
        joystickRadiusFraction = preferences.getFloat(KEY_JOYSTICK_RADIUS, 0.095f),
        cameraCenter = NormalizedPoint(
            preferences.getFloat(KEY_CAMERA_X, 0.80f),
            preferences.getFloat(KEY_CAMERA_Y, 0.70f)
        ),
        cameraDragFraction = preferences.getFloat(KEY_CAMERA_DRAG, 0.17f),
        jumpButton = NormalizedPoint(
            preferences.getFloat(KEY_JUMP_X, 0.91f),
            preferences.getFloat(KEY_JUMP_Y, 0.84f)
        ),
        interactButton = NormalizedPoint(
            preferences.getFloat(KEY_INTERACT_X, 0.90f),
            preferences.getFloat(KEY_INTERACT_Y, 0.60f)
        )
    )

    fun save(profile: TouchProfile) {
        preferences.edit()
            .putFloat(KEY_JOYSTICK_X, profile.joystickCenter.x)
            .putFloat(KEY_JOYSTICK_Y, profile.joystickCenter.y)
            .putFloat(KEY_JOYSTICK_RADIUS, profile.joystickRadiusFraction)
            .putFloat(KEY_CAMERA_X, profile.cameraCenter.x)
            .putFloat(KEY_CAMERA_Y, profile.cameraCenter.y)
            .putFloat(KEY_CAMERA_DRAG, profile.cameraDragFraction)
            .putFloat(KEY_JUMP_X, profile.jumpButton.x)
            .putFloat(KEY_JUMP_Y, profile.jumpButton.y)
            .putFloat(KEY_INTERACT_X, profile.interactButton.x)
            .putFloat(KEY_INTERACT_Y, profile.interactButton.y)
            .apply()
    }

    companion object {
        private const val KEY_JOYSTICK_X = "joystick_x"
        private const val KEY_JOYSTICK_Y = "joystick_y"
        private const val KEY_JOYSTICK_RADIUS = "joystick_radius"
        private const val KEY_CAMERA_X = "camera_x"
        private const val KEY_CAMERA_Y = "camera_y"
        private const val KEY_CAMERA_DRAG = "camera_drag"
        private const val KEY_JUMP_X = "jump_x"
        private const val KEY_JUMP_Y = "jump_y"
        private const val KEY_INTERACT_X = "interact_x"
        private const val KEY_INTERACT_Y = "interact_y"
    }
}
