/*
 * Revolution Mobile Beta — GPL-3.0-or-later.
 * Command model for Natro-style walk scripts. Key presses become Down/Up,
 * Walk(n) keeps Natro's meaning (time to walk n tiles with the held keys),
 * Jump and Rotate map Natro's space and RotLeft/RotRight key sends.
 * Derived from Natro Macro (https://github.com/NatroTeam/NatroMacro), GNU GPL v3.
 */
package com.revolutionmobile.beta.movement

/** Movement directions, as Natro's W/A/S/D roles, mapped to joystick vectors (screen y grows downward). */
enum class Dir(val vx: Float, val vy: Float) {
    FWD(0f, -1f), BACK(0f, 1f), LEFT(-1f, 0f), RIGHT(1f, 0f)
}

/** Camera turn direction, Natro's RotLeft / RotRight. */
enum class Turn { LEFT, RIGHT }

/** Game buttons with a fixed on-screen position on mobile. Natro's E key is INTERACT. */
enum class GameButton { INTERACT }

sealed interface Cmd {
    data class Down(val dir: Dir) : Cmd
    data class Up(val dir: Dir) : Cmd

    /** Natro's Walk(tiles, hasteCap). Speed is re-evaluated for every Walk. */
    data class Walk(val tiles: Double, val hasteCap: Int = 0) : Cmd

    /** A pause. Natro's Sleep and HyperSleep both map here. */
    data class Sleep(val ms: Long) : Cmd

    /** Space pressed for [holdMs]. Movement held at that moment keeps going, as in Natro. */
    data class Jump(val holdMs: Long) : Cmd

    /** Natro's `send {RotLeft n}`: [steps] camera turns, one swipe each. */
    data class Rotate(val turn: Turn, val steps: Int) : Cmd

    /** A game button pressed for [holdMs] (Natro's `send {E down}` ... `send {E up}`). */
    data class Tap(val button: GameButton, val holdMs: Long) : Cmd
}

class Script {
    private val commands = mutableListOf<Cmd>()

    fun down(vararg dirs: Dir) {
        for (d in dirs) commands += Cmd.Down(d)
    }

    fun up(vararg dirs: Dir) {
        for (d in dirs) commands += Cmd.Up(d)
    }

    fun walk(tiles: Double, hasteCap: Int = 0) {
        require(tiles >= 0.0) { "tiles must not be negative" }
        commands += Cmd.Walk(tiles, hasteCap)
    }

    /** Natro's nm_Walk(tiles, key1, key2): hold keys, walk, release keys. */
    fun nmWalk(tiles: Double, vararg dirs: Dir) {
        down(*dirs)
        walk(tiles)
        up(*dirs)
    }

    fun sleep(ms: Long) {
        commands += Cmd.Sleep(ms)
    }

    /** Same as [sleep]; named for the pauses that appear between path steps. */
    fun pause(ms: Long) = sleep(ms)

    fun jump(holdMs: Long = 100L) {
        require(holdMs >= 0L) { "holdMs must not be negative" }
        commands += Cmd.Jump(holdMs)
    }

    fun rotate(turn: Turn, steps: Int) {
        require(steps >= 1) { "steps must be at least 1" }
        commands += Cmd.Rotate(turn, steps)
    }

    fun tap(button: GameButton, holdMs: Long = 70L) {
        require(holdMs >= 0L) { "holdMs must not be negative" }
        commands += Cmd.Tap(button, holdMs)
    }

    fun build(): List<Cmd> = commands.toList()
}

fun script(block: Script.() -> Unit): List<Cmd> = Script().apply(block).build()
