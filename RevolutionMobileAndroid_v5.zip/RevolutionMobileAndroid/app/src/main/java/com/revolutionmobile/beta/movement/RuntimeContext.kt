/*
 * Revolution Mobile Beta — GPL-3.0-or-later.
 * Everything a route needs to choose its commands. Routes take this as a parameter
 * instead of reading hive number or movement method from their own names.
 */
package com.revolutionmobile.beta.movement

import com.revolutionmobile.beta.config.AppConfig
import com.revolutionmobile.beta.config.MoveMethod

/**
 * @property config user settings.
 * @property hiveBees bees in the hive right now. Defaults to the configured value; a later
 *   screen detector can override it per run.
 * @property buffs movement buffs active right now. Empty until buff detection is ported.
 */
data class RuntimeContext(
    val config: AppConfig,
    val hiveBees: Int = config.hiveBees,
    val buffs: MoveBuffs = MoveBuffs()
) {
    val hiveSlot: Int get() = config.hiveSlot
    val moveMethod: MoveMethod get() = config.moveMethod

    /** Walk speed for this run, using the configured base speed and current buffs. */
    fun studsPerSecond(hasteCap: Int = 0): Double =
        MoveSpeed.studsPerSecond(config.baseMoveSpeed, buffs, hasteCap)
}
