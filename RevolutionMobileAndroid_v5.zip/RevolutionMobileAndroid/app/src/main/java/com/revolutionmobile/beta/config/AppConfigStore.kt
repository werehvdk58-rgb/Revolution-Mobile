/*
 * Revolution Mobile Beta — GPL-3.0-or-later.
 */
package com.revolutionmobile.beta.config

import android.content.Context

/** Saves [AppConfig] in private SharedPreferences. Corrupt values fall back to defaults. */
class AppConfigStore(context: Context) {
    private val preferences = context.getSharedPreferences("revolution_app_config", Context.MODE_PRIVATE)

    fun load(): AppConfig = try {
        AppConfig(
            hiveSlot = preferences.getInt(KEY_HIVE_SLOT, AppConfig().hiveSlot),
            moveMethod = MoveMethod.valueOf(
                preferences.getString(KEY_MOVE_METHOD, MoveMethod.WALK.name) ?: MoveMethod.WALK.name
            ),
            hiveBees = preferences.getInt(KEY_HIVE_BEES, AppConfig().hiveBees),
            baseMoveSpeed = preferences.getInt(KEY_BASE_SPEED, AppConfig().baseMoveSpeed)
        )
    } catch (error: IllegalArgumentException) {
        AppConfig()
    }

    fun save(config: AppConfig) {
        preferences.edit()
            .putInt(KEY_HIVE_SLOT, config.hiveSlot)
            .putString(KEY_MOVE_METHOD, config.moveMethod.name)
            .putInt(KEY_HIVE_BEES, config.hiveBees)
            .putInt(KEY_BASE_SPEED, config.baseMoveSpeed)
            .apply()
    }

    private companion object {
        const val KEY_HIVE_SLOT = "hive_slot"
        const val KEY_MOVE_METHOD = "move_method"
        const val KEY_HIVE_BEES = "hive_bees"
        const val KEY_BASE_SPEED = "base_speed"
    }
}
