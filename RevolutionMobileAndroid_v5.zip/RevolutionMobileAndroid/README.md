# Revolution Mobile Beta — Android port workbench

Unofficial Android porting workbench for Bee Swarm Simulator. It is not an official Revolution release and is not affiliated with the Revolution developer.

## Current implementation

- Kotlin Android app, min Android 11 (API 30).
- Accessibility Service screen capture via `takeScreenshot()`.
- Multi-touch gesture dispatch (supports two simultaneous finger paths).
- A first Android input adapter that maps Revolution-style movement directions to a Roblox mobile joystick drag and camera movement to a right-side swipe.
- Normalized touch coordinates and a local profile store, so the same layout can be calibrated for different display sizes.
- Delayed movement/camera test buttons to let the user switch to Roblox before the gesture is sent.
- A control to cancel delayed test commands before they start.
- JVM tests for coordinate normalization and joystick/camera target bounds.
- GitHub Actions workflow to run unit tests and assemble a debug APK.

- User settings in the app (hive slot, walk/cannon, bees in hive, base speed) saved in `config/AppConfigStore`. Routes receive a `RuntimeContext` as a parameter and do not hard-code the hive number or movement method.
- Routes ported from Natro: wf-pinetree (walk and cannon branches) and Tunnel Bear (Blue, Red, Mountain; walk branches only). They use jump, camera turn, button tap and pause commands.
- Port of Natro Macro's walking model (movement-speed formula, tiles → time) and its 12 gathering patterns from `patterns/`, run through a stoppable step runner (`movement/`). Speed buffs are not detected from the screen yet: the test uses base speed 28 with no buffs.

The joystick/camera ratios are provisional defaults, not verified values for every Roblox HUD layout. The test controls are manual tests only. No automatic gathering is active.

## License

GNU GPL v3 or later (see `LICENSE`), because code is ported from Natro Macro (GPL v3). Attribution is in `NOTICE`. Anyone who distributes the APK must also provide this source.

## Not ported yet

AI token/loot detection, OCR, AI pathfinding, Lua patterns, planters, dispensers, Vic Hop, and Revolution's routine scheduler. These require the actual matching source code and/or model format plus licensing checks. See [the source audit](docs/REVOLUTION_ANDROID_PORT_AUDIT.md).

## Build

Open the folder in Android Studio and run `testDebugUnitTest assembleDebug`, or push it to a GitHub repository and run `.github/workflows/android.yml`. The workflow artifact is named `Revolution-Mobile-Beta-debug`.

## Structure

- `RevolutionAccessibilityService.kt` — Android screen capture and gesture execution.
- `input/TouchProfile.kt` — normalized joystick/camera control layout and Revolution-style movement enums.
- `input/AndroidTouchController.kt` — adapts movement and camera commands to multi-touch gestures.
- `input/TouchProfileStore.kt` — persists the calibration profile.
- `ScreenAnalyzer.kt` — placeholder diagnostics for captured frames; not the Revolution AI detector.
- `docs/REVOLUTION_ANDROID_PORT_AUDIT.md` — public source audit and porting map.

## Source and licensing status

The current public `nosyliam/revolution-macro` repository exposes models, datasets, update material, images, and dependencies, but its visible file tree does not include the current desktop application's full source. The separate historical Go module is indexed as GPL-3.0, but its old GitHub source links return 404. No Revolution model weights or desktop binary code have been copied into this Android project. Before importing any model/assets, verify their license and Android compatibility.

## Natro Macro port status

Done: movement-speed formula and all 12 gathering patterns (held-key model with diagonals). Not done: the hive → ramp step (`nm_gotoramp`, not in the archive), Tunnel Bear cannon branches (`nm_gotocannon`), other paths, buff-icon speed detection, image-search detectors, field/gather loop. Timing-based walking depends on gesture latency on a real device and has not been calibrated.
