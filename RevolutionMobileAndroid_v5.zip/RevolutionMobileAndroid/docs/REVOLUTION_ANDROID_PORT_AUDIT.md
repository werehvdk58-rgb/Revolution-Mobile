# Revolution → Android: source audit and port plan

Audit date: 2026-11-01

## What is publicly available

### Current public repository

`https://github.com/nosyliam/revolution-macro` is public. Its visible top-level tree contains release/update material (`appcast`, `versions`, `versions.manifest`), datasets, images, dependencies, and model files. It does **not** expose the current desktop app's main application source tree in the repository listing. The README describes Windows/macOS features such as AI Stinger Hop, AI Pathfinding, gathering, and dispensers. The latest public release visible during this audit is `v0.9d-hotfix1` (published 2026-10-17); its notes list stability fixes, not an Android build.

The public `versions.manifest` names OCR, token/loot, sprinkler, precision, and Vic-detection assets. Most model entries are under `models/darwin` or `models/windows`; the only explicitly `universal` family visible in the manifest is Vic detection. The dependency manifest lists Windows ONNX Runtime and Linux CUDA/ROCm ONNX Runtime packages, but no Android/arm64 runtime package. This is not sufficient to conclude that all weights are unsupported on Android, but it confirms there is no ready-made Android runtime bundle in the public manifest. No model files have been copied into this project because model tensor metadata, runtime compatibility, and redistribution permissions have not been verified.

### Historical Go module

`github.com/nosyliam/revolution` is indexed by pkg.go.dev at pseudo-version `v0.0.0-20250120031029-3f890744b55a`, published 2025-01-20, with GPL-3.0 metadata. It exposes package documentation for `macro`, `pkg/common`, `pkg/config`, `pkg/movement`, `pkg/ocr`, and `platform`. The Go Packages index still documents the pseudo-version, but its source links point to `github.com/nosyliam/revolution` at commit `3f890744b55a`; opening the repository tree and `app.go` source URLs returns 404. Attempts to retrieve the module archive through the available network path did not succeed. Therefore the complete Go source archive has not been obtained. This is historical API documentation, not proof that it contains the current `revolution-macro` app implementation.

## What the historical API tells us

- `pkg/common.Backend` is a desktop I/O abstraction: key down/up, mouse move/scroll, sleep, and input attachment.
- `pkg/common.InputManager` describes character control in terms of movement keys, yaw, pitch, zoom, and reset.
- `pkg/movement` exposes walking/alignment, buff and digit detection, and Lua pattern execution functions.
- `pkg/ocr.Reader` asynchronously accepts an image and returns recognized text.
- `macro.Scheduler` processes frames and supports immediate, delayed, and interval interrupts. Its docs describe a frame-driven loop whose rate depends on the OS backend (commonly around 30 fps).
- The documented key set includes Forward/Backward/Left/Right, camera rotation, zoom, and several action keys.

These interfaces guide the Android boundary, but their implementation has not been copied: the historical source files are not currently retrievable from the linked repository.

## Android mapping implemented in this branch

| Desktop concept | Android implementation | State |
|---|---|---|
| Screen/window capture | `AccessibilityService.takeScreenshot()` | Existing prototype |
| Mouse/keyboard movement | Multi-finger `GestureDescription` | New adapter |
| Forward/back/left/right | Configurable virtual joystick drag | New adapter; defaults are provisional |
| Camera rotation | Configurable right-side camera swipe | New adapter; defaults are provisional |
| Move + look at once | Two simultaneous gesture strokes | New adapter |
| Resolution independence | Normalized touch coordinates | New profile model/store |
| Token/loot detector | Not yet ported | Blocked on actual detector/model format and licensing |
| OCR | Not yet ported | Public repo lists OCR model binaries, but no Android runtime integration or redistribution grant verified |
| Lua movement patterns | Not yet ported | Requires source archive or a clean-room interpreter/port |
| Pathfinding / task graph | Not yet ported | Requires the actual algorithm source and game-screen coordinate conventions |
| Planters / dispensers / Vic Hop | Not yet ported | Requires task routines plus Android-specific UX/network checks |

## Why we are not just compiling the desktop app for Android

The published historical `Backend` contract is based on keyboard/mouse and process IDs. Android Roblox exposes on-screen joystick/camera controls, so the input adapter must translate that control model. The public asset manifest includes Windows ONNX Runtime binaries and Linux GPU runtime bundles, but does not list Android/arm64 runtime binaries. An Android build therefore needs an Android-compatible inference runtime and verified model tensor metadata rather than reusing the desktop runtime bundle. A Windows `.exe` or macOS `.dmg` cannot be converted into an APK.

## Immediate next source requirement

To port the real current AI/pathfinding logic rather than just the documented API shape, we need the actual source repository/archive for the matching Revolution desktop release (or a maintainer-provided source snapshot). A GitHub connection may reveal repositories available to the user's account, but cannot restore a deleted repository that the account cannot access.


## Verification and current limitations

- The Android bridge now checks whether Android accepted a gesture dispatch, catches screenshot API errors, and exposes cancellation for delayed test commands. Cancellation does not interrupt a gesture that has already started.
- JVM unit tests cover normalized point scaling, joystick direction mapping, diagonal movement, and screen-bound clamping. They are wired into the CI workflow; they have not been executed in this container because Gradle/Android SDK tooling is not installed here.
- No APK has been built or tested on the user's Realme device yet.
