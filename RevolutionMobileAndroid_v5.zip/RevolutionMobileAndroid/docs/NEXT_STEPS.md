# Port backlog

## P0 — access to real algorithm sources

- Obtain the source snapshot matching the user's Revolution desktop version. The currently visible GitHub repo is an asset/model/update repository, while the historical Go module links are currently broken (404).
- Verify the license for every source tree, model, pattern, dataset, and native dependency before importing it.

## P1 — Android I/O bridge

- Calibrate the joystick and camera zones against the actual Roblox HUD. Current ratios are only approximate.
- Add continuous press/hold semantics and cancel/release semantics for the original `InputManager` key-down/key-up model.
- Add a foreground execution controller with a persistent stop button/notification before any longer automation is enabled.
- Test capture + multi-touch on the target Android device while Roblox is in the foreground.

## P2 — perception pipeline

- Identify the input/output tensor shapes and preprocessing for the actual Revolution token/loot models.
- Verify whether model weights are ONNX or another format and whether their license permits redistribution.
- Select an Android-compatible inference runtime and benchmark on the target device.
- Add game HUD/pollen, hive, tokens, planters, dispensers and quest detectors with debug overlays and confidence thresholds.

## P3 — task engine

- Port the historical scheduler concepts (immediate/delayed/interval interrupts) only after obtaining source and dependency versions.
- Port movement patterns/Lua execution, map path nodes to touch controls and validate each route manually.
- Add gathering, planters, dispensers, quests and Vic Hop in separate feature modules with independent stop/recovery paths.

## Acceptance checklist before enabling automatic play

- The game window is detected before any touch is sent.
- The macro can be stopped immediately from a persistent UI control.
- No credentials, Roblox cookies, or account tokens are collected.
- Each visual detector reports confidence and has a no-action fallback when uncertain.
- A long run can recover from app focus loss, death, disconnect, and screen rotation without uncontrolled gestures.
